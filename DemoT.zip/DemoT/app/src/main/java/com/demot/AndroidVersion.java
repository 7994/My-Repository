package com.demot;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Created by Echo on 8/22/2018.
 */

public class AndroidVersion  implements Serializable{
    public String ver;
    public String name;
    public String api;


}
