package com.demot;

/**
 * Created by Echo on 8/22/2018.
 */

public class JSONResponse {
    private AndroidVersion[] android;

    public AndroidVersion[] getAndroid() {
        return android;
    }
}