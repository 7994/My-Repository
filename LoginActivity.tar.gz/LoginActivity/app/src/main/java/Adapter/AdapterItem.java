package Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.loginactivity.R;
import com.loginactivity.ThirdActivity;

import java.util.ArrayList;
import java.util.List;

import Database.DatabaseHandler;
import Model.ItemModel;


/**
 * Created by mashuk on 26/4/16.
 */
public class AdapterItem extends BaseAdapter {

    LayoutInflater inflater;
    private Context context;
    DatabaseHandler databaseHandler;
    private int userid;
    private List<ItemModel> modelList = new ArrayList<ItemModel>();

    public AdapterItem(Context context, int userid) {
        this.context = context;
        this.userid = userid;
        inflater = LayoutInflater.from(context);
        databaseHandler = new DatabaseHandler(context);
        modelList = databaseHandler.getListViewItem();
    }

    @Override
    public int getCount() {
        return modelList.size();
    }

    @Override
    public Object getItem(int position) {
        return modelList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        convertView = inflater.inflate(R.layout.listitems, null);

        TextView txtItemName = (TextView) convertView.findViewById(R.id.txtIName);
        txtItemName.setText(modelList.get(position).getItemName());

        TextView textQTY = (TextView) convertView.findViewById(R.id.txtIQty);
        textQTY.setText(modelList.get(position).getItemQty());

        TextView textURL = (TextView) convertView.findViewById(R.id.txtIUrl);
        textURL.setText(modelList.get(position).getItemUrl());

        TextView textCreatedBy = (TextView) convertView.findViewById(R.id.txtICreatedBy);


        String textCretedBy = databaseHandler.getUser(modelList.get(position).getU_id()).getName();
        textCreatedBy.setText(textCretedBy);


        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (modelList.get(position).getU_id() == userid) {
                    Intent passIntent = new Intent(context, ThirdActivity.class);

                    passIntent.putExtra("id", modelList.get(position).getId());
//                Log.d("Item Id", "" + modelList.get(position).getId());

                    passIntent.putExtra("item_name", modelList.get(position).getItemName());
//                Log.d("Item Name", "" + modelList.get(position).getItemName());

                    passIntent.putExtra("item_qty", modelList.get(position).getItemQty());
//                Log.d("Item QTY", "" + modelList.get(position).getItemQty());

                    passIntent.putExtra("item_url", modelList.get(position).getItemUrl());
//                Log.d("Item URL", "" + modelList.get(position).getItemUrl());

                    passIntent.putExtra("Uid", modelList.get(position).getU_id());
//                Log.d("User Id ", "" + modelList.get(position).getU_id());

                    context.startActivity(passIntent);
                }

                else {
                    Toast.makeText(context, "You are not the Valid User", Toast.LENGTH_LONG).show();
                }
            }
        });


        Button btndelete = (Button) convertView.findViewById(R.id.btnDelete);

        final int selectedPos = position;

        btndelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                databaseHandler.deleteListItem(modelList.get(selectedPos).getId());
                modelList.remove(selectedPos);
                notifyDataSetChanged();
            }
        });
        return convertView;
    }
}
