package Util;

/**
 * Created by mashuk on 26/4/16.
 */
public class Constants {

    public static String UNAME = "";
    public static String UEMAIL = "";
    public static String UADDRESS = "";
    public static String UPASSWORD = "";
    public static String UPHONE = "";
}
