package com.loginactivity;

import android.annotation.TargetApi;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

import Database.DatabaseHandler;
import Model.PersonDb;

public class MainActivity extends AppCompatActivity {

    private EditText edtUname;
    private EditText edtPass;
    private Button btnLogin;
    private Button btnSignUp;
    private SharedPreferences prefs;
    int UserId;
    DatabaseHandler dbasehandler;
    private CheckBox checkboxRemember;

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Window window = getWindow();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.setStatusBarColor(getResources().getColor(R.color.color1));
        }

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        edtUname = (EditText) findViewById(R.id.edtUname);
        edtPass = (EditText) findViewById(R.id.edtPass);
        btnLogin = (Button) findViewById(R.id.btnLogin);
        btnSignUp = (Button) findViewById(R.id.btnSignup);
        checkboxRemember = (CheckBox)findViewById(R.id.checkboxRemember);

        prefs = getSharedPreferences("loginshared", MODE_PRIVATE);
//        boolean status = prefs.getBoolean("status", false);
        dbasehandler = new DatabaseHandler(MainActivity.this);


        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginCheck();
            }
        });

        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent j = new Intent(MainActivity.this, SignUp.class);
                startActivity(j);
            }
        });

    }

    private void loginCheck() {

        String idcheck = edtUname.getText().toString().trim();
        String passwordcheck = edtPass.getText().toString().trim();

        if (idcheck.equals("") && !passwordcheck.equals("")) {
            Toast.makeText(MainActivity.this, "Please insert Id.", Toast.LENGTH_SHORT).show();

        } else if (!idcheck.equals("") && passwordcheck.equals("")) {
            Toast.makeText(MainActivity.this, "Please insert Password.", Toast.LENGTH_SHORT).show();
        } else if (idcheck.equals("") && passwordcheck.equals("")) {
            Toast.makeText(MainActivity.this, "Please insert Id and Password.", Toast.LENGTH_SHORT).show();
        }

        else if (!idcheck.equals("") && !passwordcheck.equals("")) {


            ArrayList<PersonDb> loginIdDetail=dbasehandler.getLoginIdDetail(idcheck, passwordcheck);

            if(loginIdDetail.size()>0) {
                Log.d("Size of ArrayList", "" + loginIdDetail.size());
                UserId= loginIdDetail.get(0).getId();
            }

            if (checkboxRemember.isChecked()) {
                SharedPreferences.Editor edit = prefs.edit();
                edit.putBoolean("status", true);
                edit.putString("name", idcheck);
                edit.commit();
            }

            if(loginIdDetail !=null && loginIdDetail.size()==0 )
            {
                Log.d("Display", "Not Record");
                Toast.makeText(MainActivity.this,"User does not Exist",Toast.LENGTH_LONG).show();
            }
            else {
                Log.d("Display", "Record----"+ loginIdDetail.get(0).getId());
                Intent intent=new Intent(MainActivity.this,SecondActivity.class);
                intent.putExtra("USERNAME", loginIdDetail.get(0).getId());
               // intent.putExtra("User_ID", UserId);
                startActivity(intent);
                finish();
            }
        }
    }
}