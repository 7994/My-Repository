package com.loginactivity;

import android.annotation.TargetApi;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import Adapter.AdapterItem;
import Database.DatabaseHandler;
import Model.ItemModel;

/**
 * Created by mashuk on 25/4/16.
 */
public class SecondActivity extends AppCompatActivity {
    private ListView list;
    private ImageView imagevwAdd;
    private ArrayList<ItemModel> myModelList = new ArrayList<ItemModel>();
    DatabaseHandler databaseHandler;
    private static final int RESULT_ADD_ITEM = 1;
    private AdapterItem adapterMyList;
    private Intent intent;
    private int userid;
    private Button btnLogout;
    private SharedPreferences prefss;
    private TextView txtUserName;
//    private String userName;


    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        Window window = getWindow();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.setStatusBarColor(getResources().getColor(R.color.colorStatusbarSignup));
        }


        imagevwAdd = (ImageView) findViewById(R.id.imageViewAdd);
        list = (ListView) findViewById(R.id.listView);
        btnLogout = (Button) findViewById(R.id.btnLogout);
        txtUserName = (TextView) findViewById(R.id.txtUsername);

        intent = getIntent();
        databaseHandler = new DatabaseHandler(this);

        prefss = getSharedPreferences("loginshared", MODE_PRIVATE);

        String n = prefss.getString("name", null);
        txtUserName.setText(n);

        if (intent != null) {
            if (intent.hasExtra("USERNAME")) {

                userid = intent.getIntExtra("USERNAME", 0);
                //userName=databaseHandler.getUserName(userid);
                Log.d("User Name", "" + userid);

                adapterMyList = new AdapterItem(SecondActivity.this, userid);
                list.setAdapter(adapterMyList);
            }
        }

/*
        adapterMyList = new AdapterItem(SecondActivity.this, userName,userid);
        list.setAdapter(adapterMyList);
*/
        myModelList = new ArrayList<>();

        imagevwAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent additem = new Intent(SecondActivity.this, AddItem.class);
                additem.putExtra("loginid", userid);
                startActivityForResult(additem, RESULT_ADD_ITEM);
            }
        });

        btnLogout.setOnClickListener(new View.OnClickListener() {
            private SharedPreferences prefs;

            @Override
            public void onClick(View v) {
                prefs = getSharedPreferences("loginshared", MODE_PRIVATE);
                SharedPreferences.Editor edit = prefs.edit();
                prefs.edit().remove("name");
                edit.clear();
                edit.commit();


                Intent back = new Intent(SecondActivity.this, MainActivity.class);
                startActivity(back);

                finish();
            }
        });
    }

// To update in the List

    @Override
    protected void onResume() {


        adapterMyList = new AdapterItem(SecondActivity.this, userid);
        list.setAdapter(adapterMyList);

        super.onResume();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // String str = data.getStringExtra(Constants.EXTRA_KEY_ABC);
        if (requestCode == RESULT_ADD_ITEM) {
            if (resultCode == RESULT_OK) {
                //adapterMyList = new AdapterItem(SecondActivity.this, userName, userid);

                myModelList.clear();

                adapterMyList = new AdapterItem(SecondActivity.this, userid);
                adapterMyList.notifyDataSetChanged();
                list.setAdapter(adapterMyList);

                //adapterMyList.notifyDataSetChanged();
                Log.d("Activity from", "....Item Insert....");
                Toast.makeText(SecondActivity.this, "Item Added - RESULT_OK", Toast.LENGTH_SHORT).show();
            }

            if (resultCode == RESULT_CANCELED) {
                Log.d("Activity from", ".....Result Cancel....");
            }
        }
    }
}

