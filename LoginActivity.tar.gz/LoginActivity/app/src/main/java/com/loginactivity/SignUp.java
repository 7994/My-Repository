package com.loginactivity;

import android.annotation.TargetApi;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import Database.DatabaseHandler;

/**
 * Created by mashuk on 25/4/16.
 */
public class SignUp extends AppCompatActivity {

    private EditText edtName;
    private EditText edtEmail;
    private EditText edtAddress;
    private EditText edtPassword;
    private EditText edtPhone;
    private Button btnSubmit;
    private Button btnClear;
    private ImageView imbBack;
    DatabaseHandler databaseHandler;
    private EditText edtImageSrc;
    private Button btnBrowse;
    private static final int SELECT_PICTURE = 1;

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

// To change StatusBar Color

        Window window = getWindow();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.setStatusBarColor(getResources().getColor(R.color.colorBrown));
        }

// To Hide Edittext Focusability Forcefully

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

// EditText Ids

        edtName = (EditText) findViewById(R.id.edtName);
        edtEmail = (EditText) findViewById(R.id.edtEmail);
        edtAddress = (EditText) findViewById(R.id.edtAddress);
        edtPassword = (EditText) findViewById(R.id.edtPassword);
        edtPhone = (EditText) findViewById(R.id.edtPhone);
        edtImageSrc = (EditText) findViewById(R.id.edtImageSrc);

        imbBack = (ImageView) findViewById(R.id.imageback);

// Button Ids

        btnBrowse = (Button) findViewById(R.id.btnBrowse);
        btnSubmit = (Button) findViewById(R.id.btnSubmit);
        btnClear = (Button) findViewById(R.id.btnClear);


        databaseHandler = new DatabaseHandler(this);

        imbBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent b = new Intent(SignUp.this, MainActivity.class);
                startActivity(b);
                finish();
            }
        });

        btnBrowse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent, "Select Picture"), SELECT_PICTURE);

            }
        });

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String strName = edtName.getText().toString();
                String strEmail = edtEmail.getText().toString();
                String strAddress = edtAddress.getText().toString();
                String strPassword = edtPassword.getText().toString();
                String strPhone = edtPhone.getText().toString();

                if (!isValidEmail(strEmail)) {
                    edtEmail.setError("Enter Valid Email");
                }

                if (!strName.equals("") && !strEmail.equals("") && isValidEmail(strEmail) && !strAddress.equals("") && !strPassword.equals("") && !strPhone.equals("")) {
                    databaseHandler.insertData(strName.trim(), strEmail.trim(), strAddress.trim(), strPassword.trim(), strPhone.trim());
                    Toast.makeText(SignUp.this, "Successfully Registered", Toast.LENGTH_LONG).show();
                    clear();
                    finish();
                } else {
                    Toast.makeText(SignUp.this, "Please Insert Data", Toast.LENGTH_LONG).show();
                }
            }
        });

        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clear();
            }
        });
    }

// Email Validation

    private boolean isValidEmail(String s) {

        String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@" + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";

        Pattern pattern = Pattern.compile(EMAIL_PATTERN);
        Matcher matcher = pattern.matcher(s);
        return matcher.matches();
    }

    private void clear() {

        edtName.setText("");
        edtEmail.setText("");
        edtAddress.setText("");
        edtPassword.setText("");
        edtPhone.setText("");
    }
}
