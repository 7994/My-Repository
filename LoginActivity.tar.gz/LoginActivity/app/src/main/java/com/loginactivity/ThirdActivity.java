package com.loginactivity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import Adapter.AdapterItem;
import Database.DatabaseHandler;
import Model.ItemModel;
import Model.PersonDb;

/**
 * Created by mashuk on 27/4/16.
 */
public class ThirdActivity extends AppCompatActivity {

    private EditText edtUpdtName;
    private EditText edtUpdtQty;
    private EditText edtUpdtUrl;
    private Button btnUpdt;
    private Button btnUpdtCancel;
    DatabaseHandler dataHandler;
    private TextView txtItemId;
    int strUid;
    ArrayList<ItemModel> modellist;
    ArrayList<PersonDb> loginModelArrayList;
    AdapterItem itemadap;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);

        modellist = new ArrayList<>();

        edtUpdtName = (EditText) findViewById(R.id.edtUpdtItemName);
        edtUpdtQty = (EditText) findViewById(R.id.edtUpdtQty);
        edtUpdtUrl = (EditText) findViewById(R.id.edtUpdtUrl);
        txtItemId = (TextView) findViewById(R.id.txtItemId);
        btnUpdt = (Button) findViewById(R.id.btnUpdateItem);
        btnUpdtCancel = (Button) findViewById(R.id.btnUpClear);

        dataHandler = new DatabaseHandler(this);
//        itemadap = new AdapterItem(this, userid);

        int strIId;

        String strIname = edtUpdtName.getText().toString();
        String strIQty = edtUpdtQty.getText().toString();
        String strIUrl = edtUpdtUrl.getText().toString();
       // Integer intUid = Integer.valueOf(txtItemId.getText().toString());



        Intent i = getIntent();

        if (i != null) {

            if (i.hasExtra("item_name") && i.hasExtra("item_qty") && i.hasExtra("item_url")) {


                strIId = i.getIntExtra("id", 0);
//                Log.d("Item Id-------", "" + strIId);

                strIname = i.getStringExtra("item_name");
//                Log.d("Item Name", "" + strIname);

                strIQty = i.getStringExtra("item_qty");
//                Log.d("Item Qty", "" + strIQty);

                strIUrl = i.getStringExtra("item_url");
//                Log.d("Item Url", "" + strIUrl);

                strUid = i.getIntExtra("Uid", 0);
//                Log.d("Item Url", "" + strUid);


                txtItemId.setText("" + i.getIntExtra("id", 0));
                edtUpdtName.setText(strIname);
                edtUpdtQty.setText(strIQty);
                edtUpdtUrl.setText(strIUrl);
            }

        }


//        modellist = dataHandler.getListViewItem();


/*
        if (loginModelArrayList.size() > 0) {

            Log.i("++", "++" + loginModelArrayList.size());

        }
        for (int j = 0; j < loginModelArrayList.size(); j++) {

            String strListusername = loginModelArrayList.get(j).getName();
            Log.d("*****username",""+strListusername);
        }
*/


        btnUpdt.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                String strName = edtUpdtName.getText().toString();
                String strQty = edtUpdtQty.getText().toString();
                String strUrl = edtUpdtUrl.getText().toString();


                if (!isValidUrl(strUrl)) {
                    edtUpdtUrl.setError("Enter Valid Url");
                } else {

//                    Log.e("*****", "" + strName + "" + strQty + "" + strUrl + "");
                    int i = dataHandler.updatedetail(Integer.parseInt(txtItemId.getText().toString()), strName, strQty, strUrl);
//                    Log.e("****Int**", ""+i);

                    Toast.makeText(getBaseContext(), "Update successfull.", Toast.LENGTH_LONG).show();

                    if ( i==1){
                        finish();
                        //startActivity(getIntent());
                    }else{
                        Toast.makeText(getBaseContext(), "Update unsuccessful.", Toast.LENGTH_LONG).show();
                    }
                }
            }
        });

        btnUpdtCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edtUpdtName.setText("");
                edtUpdtQty.setText("");
                edtUpdtUrl.setText("");
            }
        });
    }

    public boolean isValidUrl(String txtWebsite) {

        String URL_PATTERN = "^[a-zA-Z0-9\\-\\.]+\\.(co|com|org|net|mil|edu|COM|ORG|NET|MIL|EDU)$";

        Pattern regex = Pattern.compile(URL_PATTERN);
        Matcher matcher = regex.matcher(txtWebsite);
        return matcher.matches();
    }
}
