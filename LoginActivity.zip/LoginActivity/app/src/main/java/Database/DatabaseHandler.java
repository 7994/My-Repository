package Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;

import Model.ItemModel;
import Model.PersonDb;

/**
 * Created by mashuk on 25/4/16.
 */
public class DatabaseHandler extends SQLiteOpenHelper {

    private Context context = null;
    public static final String TABLE_NAME = "person_details";
    public static final String DATABASE_NAME = "details1.db";
    public static final String ITEM_TABLE_NAME = "item_table";
    public final static String DATABASE_PATH = "/data/data/com.loginactivity/databases/";
    public static final int DATABASE_VERSION = 1;
    public static final String KEY_ID = "id";
    public static final String INAME = "item_name";
    public static final String IQTY = "item_qty";
    public static final String IURL = "item_URL";
    private SQLiteDatabase ItemDatabase;


    public DatabaseHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;

        try {
            createDatabase();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        ItemDatabase = db;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }


// Checks Database already exists or not

    private boolean checkDatabaseExists() {
        boolean checkDB = false;

        try {
            String PATH = DATABASE_PATH + DATABASE_NAME;
            File dbFile = new File(PATH);
            checkDB = dbFile.exists();
        }
        catch (SQLiteException e) {
        }

        return checkDB;
    }

// Creates  an empty database on the System

    public void createDatabase() throws IOException {
        boolean dbExist = checkDatabaseExists();

        if (dbExist) {
//            Log.v("DB Exists", "db exists");
            // By calling this method here onUpgrade will be called on a
            // writeable database, but only if the version number has been
            // bumped
            // onUpgrade(myDataBase, DATABASE_VERSION_old, DATABASE_VERSION);
        }

        boolean dbExist1 = checkDatabaseExists();
        if (!dbExist1) {
            this.getWritableDatabase();
            try {
                this.close();
                copyDataBase();
            } catch (IOException e) {
                throw new Error("Error copying database");
            }
        }
    }

//Copies your database from your local assets-folder to the just created empty database in the system folder

    private void copyDataBase() throws IOException {
        String outFileName = DATABASE_PATH + DATABASE_NAME;
        OutputStream myOutput = new FileOutputStream(outFileName);
        InputStream myInput = context.getAssets().open(DATABASE_NAME);

        byte[] buffer = new byte[1024];
        int length;
        while ((length = myInput.read(buffer)) > 0) {
            myOutput.write(buffer, 0, length);
        }
        myInput.close();
        myOutput.flush();
        myOutput.close();
    }

// Open DataBase

    public void openDatabase() throws SQLException {
        String PATH = DATABASE_PATH + DATABASE_NAME;
        ItemDatabase = SQLiteDatabase.openDatabase(PATH, null, SQLiteDatabase.OPEN_READWRITE);
    }

// Close DataBase

    @Override
    public synchronized void close() {
        if (ItemDatabase != null) {
            ItemDatabase.close();
        }
        super.close();
    }

// Insert data into sign up

    public void insertData(String username, String email, String address, String password, String phone, String image) {

        try {
            openDatabase();
            ContentValues insertValue = new ContentValues();
            insertValue.put("name", username);
            insertValue.put("email", email);
            insertValue.put("address", address);
            insertValue.put("password", password);
            insertValue.put("phone", phone);
            insertValue.put("image", image);

            ItemDatabase.insert(TABLE_NAME, null, insertValue);
            ItemDatabase.close();
            ItemDatabase.releaseMemory();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

// Insert data into item

    public void insertItem(int loginid, String itemname, String qty, String URL) {

        try {
            openDatabase();
            ContentValues insertValue = new ContentValues();

            insertValue.put("u_id", loginid);
//            Log.d("user_id", "" + loginid);

            insertValue.put("item_name", itemname);
//            Log.d("item_Name", "" + itemname);

            insertValue.put("item_qty", qty);
//            Log.d("item_qty", "" + qty);

            insertValue.put("item_URL", URL);
//            Log.d("item_url", "" + URL);


            ItemDatabase.insert(ITEM_TABLE_NAME, null, insertValue);
            ItemDatabase.close();
            ItemDatabase.releaseMemory();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

// Get Login Details

    public ArrayList<PersonDb> getLoginIdDetail(String username, String password) {

        ArrayList<PersonDb> result = new ArrayList<PersonDb>();
        //boolean flag = false;
        String selectQuery = "SELECT * FROM " + TABLE_NAME + " WHERE name='" + username + "' AND password='" + password + "'";
        try {
            openDatabase();
            Cursor cursor = ItemDatabase.rawQuery(selectQuery, null);
            //cursor.moveToFirst();


            if (cursor.getCount() > 0) {
                if (cursor.moveToFirst()) {
                    do {
                        PersonDb model = new PersonDb();
                        model.setId(cursor.getInt(cursor.getColumnIndex("id")));
                        model.setName(cursor.getString(cursor.getColumnIndex("name")));
                        result.add(model);
                    }
                    while (cursor.moveToNext());
                }
            }

//            Log.e("Count", "" + cursor.getCount());
            cursor.close();
            ItemDatabase.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

// Get List in Items

    public ArrayList<ItemModel> getListViewItem() {

        ArrayList<ItemModel> result = new ArrayList<ItemModel>();
        try {
            openDatabase();

            Cursor cursor = ItemDatabase.rawQuery("SELECT * FROM " + ITEM_TABLE_NAME, null);
            if (cursor.getCount() > 0) {
                if (cursor.moveToFirst()) {
                    do {

                        ItemModel model = new ItemModel();
                        model.setId(cursor.getInt(cursor.getColumnIndex("id")));
                        model.setItemName(cursor.getString(cursor.getColumnIndex("item_name")));
                        model.setItemQty(cursor.getString(cursor.getColumnIndex("item_qty")));
                        model.setItemUrl(cursor.getString(cursor.getColumnIndex("item_URL")));
                        model.setU_id(cursor.getInt(cursor.getColumnIndex("u_id")));
                        result.add(model);

                    } while (cursor.moveToNext());
                }
            }
            cursor.close();
            ItemDatabase.close();


        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

// Get User ID

    public PersonDb getUser(int id) {

        PersonDb loginModel = null;
//        Log.e("**********", "" + id);


        String selectQuery = "SELECT * FROM " + TABLE_NAME + " WHERE id=" + id;
        //openDatabase();

        try {
            openDatabase();
            Cursor cursor = ItemDatabase.rawQuery(selectQuery, null);

            if (cursor.getCount() > 0) {
                if (cursor.moveToFirst()) {
                    do {
                        loginModel = new PersonDb();
                        loginModel.setId(cursor.getInt(cursor.getColumnIndex("id")));
                        loginModel.setName(cursor.getString(cursor.getColumnIndex("name")));
                        loginModel.setEmail(cursor.getString(cursor.getColumnIndex("email")));
                        loginModel.setAddress(cursor.getString(cursor.getColumnIndex("address")));
                        loginModel.setPassword(cursor.getString(cursor.getColumnIndex("password")));
                        loginModel.setPhone(cursor.getInt(cursor.getColumnIndex("phone")));
                        loginModel.setImage(cursor.getString(cursor.getColumnIndex("image")));

                    } while (cursor.moveToNext());
                }
            }

//            Log.d("$$$$$$", loginModel.getName());
//            Log.e("Count", "" + cursor.getCount());

            cursor.close();
            ItemDatabase.close();
        } catch (Exception e) {
            e.printStackTrace();
            Log.d("Error", "Error------");
        }
        return loginModel;
    }

// Updates Item Details

    public int updatedetail(int rowId, String iname, String iqty, String iurl) {


//        Log.e("********", "SQL START");
        openDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(INAME, iname);
        contentValues.put(IQTY, iqty);
        contentValues.put(IURL, iurl);
//        Log.e("********", "SQL START" + contentValues);

        return ItemDatabase.update(ITEM_TABLE_NAME, contentValues, "id=" + rowId, null);
        // return ItemDatabase.update(ITEM_TABLE_NAME, contentValues, KEY_ID + " = ?", new String[] { String.valueOf(rowId) });
    }

// Delete Items From List

    public void deleteListItem(int id) {

        try {
            openDatabase();
            ItemDatabase.delete(ITEM_TABLE_NAME, "id=" + id, null);
            ItemDatabase.close();
            ItemDatabase.releaseMemory();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
