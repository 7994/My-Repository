package Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

import Model.PersonDb;

/**
 * Created by mashuk on 25/4/16.
 */
public class PersonDetails {

    private static final String KEY_RAW_ID = "Id";
    private static final String KEY_PNAME = "Pname";
    private static final String KEY_PEMAIL = "Pemail";
    private static final String KEY_PADDRESS = "Paddress";
    private static final String KEY_PPASSWORD = "Ppassword";
    private static final String KEY_PPHONE = "Pphone";

    private static final String DATABASE_NAME = "details1.db";
    private static final String DATABASE_TABLE = "person_details";

    private static final int DATABASE_VERSION = 1;

    private static final String[] column = {KEY_PNAME};

    //Useful objects
    private final Context ourContext;
    private DBHelper ourHelper;
    private SQLiteDatabase ourDatabase;

    public PersonDetails(Context context) {
        this.ourContext = context;
    }

    private class DBHelper extends SQLiteOpenHelper {

        public DBHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
            // TODO Auto-generated constructor stub
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            // TODO Auto-generated method stub
/*
            String query = "CREATE TABLE IF NOT EXISTS " + DATABASE_TABLE +
                    " (" + KEY_RAW_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + KEY_PNAME + " TEXT NOT NULL, "
                    + KEY_PEMAIL + " TEXT NOT NULL, "
                    + KEY_PADDRESS + " TEXT NOT NULL, "
                    + KEY_PPASSWORD + " TEXT NOT NULL, "
                    + KEY_PPHONE + " TEXT NOT NULL);";

            Log.d("SQL Query", query);

            db.execSQL(query);
*/

        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            // TODO Auto-generated method stub
            db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE);
            onCreate(db);
        }

    }

    public PersonDetails open() {

        ourHelper = new DBHelper(ourContext);
        ourDatabase = ourHelper.getWritableDatabase();

        return this;
    }

    public void close() {
        ourHelper.close();
    }


    //insert
    public void insert(String name, String email, String address, String password, String phone) {
        ContentValues values = new ContentValues();

        open();
        values.put(KEY_PNAME, name);
        values.put(KEY_PEMAIL, email);
        values.put(KEY_PADDRESS, address);
        values.put(KEY_PPASSWORD, password);
        values.put(KEY_PPHONE, phone);
        ourDatabase.insert(DATABASE_TABLE, null, values);
        close();

    }

 /*   //read all
    public ArrayList<PersonDb> getDetails() {
        ArrayList<PersonDb> details = new ArrayList<PersonDb>();

        Cursor c = ourDatabase.query(DATABASE_TABLE, column, null, null, null, null, null);

        for (c.moveToFirst(); !c.isAfterLast(); c.moveToNext()) {

            PersonDb det = new PersonDb();

            int iPname = c.getColumnIndex(KEY_PNAME);
            int iPemail = c.getColumnIndex(KEY_PEMAIL);
            int iPaddress = c.getColumnIndex(KEY_PADDRESS);
            int iPpassword = c.getColumnIndex(KEY_PPASSWORD);
            int iPphone = c.getColumnIndex(KEY_PPHONE);
        }
        return details;
    }*/


    public String getSinlgeEntry(String userName)
    {
        Cursor cursor= ourDatabase.query("person_details", null, " name=?", new String[]{userName}, null, null, null);
        if(cursor.getCount()<1) // UserName Not Exist
        {
            cursor.close();
            return "NOT EXIST";
        }
        cursor.moveToFirst();
        String password= cursor.getString(cursor.getColumnIndex("password"));
        cursor.close();
        return password;
    }
}
