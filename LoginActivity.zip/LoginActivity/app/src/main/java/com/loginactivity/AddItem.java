package com.loginactivity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import Database.DatabaseHandler;

/**
 * Created by mashuk on 25/4/16.
 */
public class AddItem extends AppCompatActivity {

    private EditText edtItemName;
    private EditText edtQty;
    private EditText edtUrl;
    private Button btnAddItem;
    private Button btnClear2;
    private Intent i;
    private int username;
    DatabaseHandler dataHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_additem);

        edtItemName = (EditText) findViewById(R.id.edtItemName);
        edtQty = (EditText) findViewById(R.id.edtQty);
        edtUrl = (EditText) findViewById(R.id.edtUrl);
        btnAddItem = (Button) findViewById(R.id.btnAddItem);
        btnClear2 = (Button) findViewById(R.id.btnClear2);

        dataHandler = new DatabaseHandler(this);

        btnAddItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String strItemName = edtItemName.getText().toString();
                String strQty = edtQty.getText().toString();
                String strUrl = edtUrl.getText().toString();

                i = getIntent();

                if (i != null) {

                    if (i.hasExtra("loginid")) {

                        username = i.getIntExtra("loginid",0);

                        Log.d("UserName---", ""+username);
                    }
                }

                if (!isValidUrl(strUrl)) {
                    edtUrl.setError("Enter Valid Url");
                }

                if (!strItemName.equals("") && !strQty.equals("") && !strUrl.equals("") && isValidUrl(strUrl)) {
                    //if (Email.matches(emailPattern)) {
                    dataHandler.insertItem(username, strItemName.trim(), strQty.trim(), strUrl.trim());
                    Toast.makeText(AddItem.this, "Items Added", Toast.LENGTH_LONG).show();
                    //}

                    Intent i = new Intent();
                    setResult(RESULT_OK, i);
                    finish();
                }

                else{
                    Toast.makeText(AddItem.this, "Please Insert Data", Toast.LENGTH_LONG).show();
                }
                clear();
            }
        });

        btnClear2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clear();
                finish();
            }
        });
    }


    private void clear() {

        edtItemName.setText("");
        edtQty.setText("");
        edtUrl.setText("");
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

        Intent secondactivity = new Intent();
        finish();
    }


//  Web Url Validation

    public boolean isValidUrl (String txtWebsite){

        String URL_PATTERN = "^[a-zA-Z0-9\\-\\.]+\\.(com|org|net|mil|edu|COM|ORG|NET|MIL|EDU)$";

        Pattern regex = Pattern.compile(URL_PATTERN);
        Matcher matcher = regex.matcher(txtWebsite);
        return matcher.matches();
    }
}
