package com.loginactivity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by mashuk on 5/5/16.
 */
public class EditSignUp extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editsignup);
    }
}
