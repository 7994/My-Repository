package com.loginactivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by mashuk on 25/4/16.
 */

public class SplashScreen extends AppCompatActivity {

    private static int Splash_timeout = 1600;
    private SharedPreferences prefss;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
/*
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
*/
        prefss=getSharedPreferences("loginshared",MODE_PRIVATE);

        String n=prefss.getString("name", null);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

                if(prefss.contains("name")){
                    Intent i = new Intent(SplashScreen.this, SecondActivity.class);
                    startActivity(i);
                    finish();
                }

                else {
                    Intent i = new Intent(SplashScreen.this, MainActivity.class);
                    startActivity(i);
                    finish();
                }
            }
        }, Splash_timeout);
    }
}
