package com.example.customizelv1;

import java.util.ArrayList;

import model.ListData;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView.FindListener;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class BaseAdap extends BaseAdapter{
	
	ArrayList mylist = new ArrayList();
	Context context;
	LayoutInflater inflater;
	
	public BaseAdap(Context context, ArrayList mylist){
	
		this.mylist = mylist;
		this.context = context;
		inflater = LayoutInflater.from(context);
		
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return mylist.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return mylist.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		MyViewHolder mholder;
		if(convertView == null){
			
			convertView = inflater.inflate(R.layout.list_items, parent, false);
			
			mholder = new MyViewHolder(convertView);
			
			convertView.setTag(mholder);
			
		}
		
		else{
			mholder = (MyViewHolder) convertView.getTag();
		}
		
		ListData currentListData = (ListData) getItem(position);
		mholder.tvName.setText(currentListData.getName());
		mholder.tvVersion.setText(currentListData.getVersion());
		mholder.tvApi.setText(currentListData.getApi());
		mholder.ivIcon.setImageResource(currentListData.getImgResId());
		
		return convertView;
	}

	public class MyViewHolder{
		TextView tvName, tvVersion, tvApi;
		ImageView ivIcon;
		
		public MyViewHolder(View item){
			
			tvName = (TextView)item.findViewById(R.id.txtUname);
			tvVersion = (TextView)item.findViewById(R.id.txtDesc);
			tvApi = (TextView)item.findViewById(R.id.txtapi);
			ivIcon = (ImageView)item.findViewById(R.id.imageView1);
		}
	}
}