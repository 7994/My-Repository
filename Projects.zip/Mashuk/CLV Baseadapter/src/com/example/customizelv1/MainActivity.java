package com.example.customizelv1;

import java.util.ArrayList;

import model.ListData;

import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.database.DataSetObserver;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;

public class MainActivity extends Activity {

    ListView list;
    ArrayList mylistdata = new ArrayList();   
    Context context = MainActivity.this;
    
    String[] Title = new String[] {"Cupcake", "Donut", "Eclair", "Froyo", "GingerBread", "HoneyComb", "Icecream Sandwich", "Jellybean", "Kitkat", "Lollipop", "Marshmallow"};
    String[] Version = new String[] {"1.5", "1.6", "2.0-2.1", "2.2-2.2.3","2.3�2.3.7", "3.0�3.2.6", "4.0�4.0.4", "4.1�4.3.1", "4.4�4.4.4, 4.4W�4.4W.2", "5.0�5.1.1", "6.0�6.0.1" };
    String[] API = new String[] {"3", "4", "5-7", "8", "9�10", "11�13", "14�15", "16�18", "19�20", "21�22", "23" };
    int[] img = new int[] {R.drawable.cupcake, R.drawable.donut, R.drawable.eclair, R.drawable.froyo, R.drawable.gingerbread, R.drawable.honeycomb, R.drawable.icecream, R.drawable.jellybean, R.drawable.kitkat, R.drawable.lollipop, R.drawable.marshmallow};
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
            
        list = (ListView)findViewById(R.id.listView1);
        getDataInList();
        BaseAdapter ad = new BaseAdap(context, mylistdata);
        list.setAdapter(ad);
    }
    
    private void getDataInList(){
    	
    	for(int i = 0; i < Title.length; i++){
    		ListData ld = new ListData();
    		ld.setName(Title[i]);
    		ld.setVersion(Version[i]);
    		ld.setApi(API[i]);
    		ld.setImgResId(img[i]);
    		
    		mylistdata.add(ld);
    	}
    }
}