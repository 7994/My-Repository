package model;

public class ListData {
	
	private String Name;
	private String Version;
	private String Api;
	private int ImgResId;
	
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getVersion() {
		return Version;
	}
	public void setVersion(String version) {
		Version = version;
	}
	public String getApi() {
		return Api;
	}
	public void setApi(String api) {
		Api = api;
	}
	public int getImgResId() {
		return ImgResId;
	}
	public void setImgResId(int imgResId) {
		ImgResId = imgResId;
	}
	
	

}
