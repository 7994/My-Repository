package com.example.customizelv;

import java.util.ArrayList;
import java.util.jar.Attributes.Name;

import Model.ListData;
import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends Activity {

	private ListView list;
	private ArrayList<ListData> data;
	private int[] resourceImages = {R.drawable.a, R.drawable.b, R.drawable.c};
	private SetDataAdapter adapter;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		data = new ArrayList<ListData>();
		for(int i=0; i<3; i++){
			ListData d = new ListData();
			d.setName("I am number " + i);
			d.setDescription("Description" + i);
			data.add(d);
		}
		
		adapter = new SetDataAdapter();
		list = (ListView)findViewById(R.id.listView1);
		list.setAdapter(adapter);
	}

	
	private class SetDataAdapter extends BaseAdapter {

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return data.size();
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return data.get(position);
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			// TODO Auto-generated method stub
			ViewHolder holder = null;
			
			if(convertView==null){
				
				convertView = getLayoutInflater().inflate(R.layout.list_items, parent, false);
				
				holder = new ViewHolder();
				holder.image = (ImageView)convertView.findViewById(R.id.imageView1);
				holder.name = (TextView)convertView.findViewById(R.id.txtUname);
				holder.desc = (TextView)convertView.findViewById(R.id.txtDesc);
			}
			
			else {
				
				holder = (ViewHolder)convertView.getTag();
			}
			
			holder.name.setText(data.get(position).getName());
			holder.desc.setText(data.get(position).getDescription());
			holder.image.setImageResource(resourceImages[position]);
			
			return convertView;
		}
		
	}
		
	private static class ViewHolder{
		ImageView image;
		TextView name;
		TextView desc;
	}

}
