package com.ecommerce.api;

public class APIResources {
	
	public static final String BASE_URL = "http://10.3.0.1/ecomm/";
	
	public static final String GET_CATEGORY = "getcategory.php";
	
	public static final String GET_PRODUCTS = "getproduct.php?catId=";

}
