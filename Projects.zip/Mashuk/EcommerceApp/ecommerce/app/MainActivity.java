package com.ecommerce.app;

import java.util.ArrayList;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.ecommerce.api.APICall;
import com.ecommerce.data.CategoryData;
import com.ecommerce.tables.Category;

public class MainActivity extends Activity {

	private CategoryData categories;
	private ArrayList<String> items;
	private ArrayAdapter<String> adapter;
	private ListView list;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		categories = new CategoryData();
		items = new ArrayList<String>();
		
		adapter = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1, items);
		
		list = (ListView) findViewById(R.id.listView1);
		
		list.setAdapter(adapter);
		
		list.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				//Toast.makeText(MainActivity.this,categories.getCategories().get(arg2).getCategoryId(), Toast.LENGTH_SHORT).show();
				String catId = categories.getCategories().get(arg2).getCategoryId();
				
				Intent products = new Intent(MainActivity.this, ProductsActivity.class);
				products.putExtra("catId", catId);
				startActivity(products);
				
			}
		});
		
		
		
		
		// Background async task
		new GetAllCategories().execute();
		
	}

	private class GetAllCategories extends AsyncTask<Void, Void, CategoryData>{
		
		private ProgressDialog dialog;
		
		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			dialog = new ProgressDialog(MainActivity.this);
			dialog.setMessage("Loading...!");
			dialog.setTitle("Category");
			dialog.setIcon(R.drawable.ic_launcher);
			dialog.show();
			super.onPreExecute();
		}

		@Override
		protected CategoryData doInBackground(Void... params) {
			// TODO Auto-generated method stub
			
			CategoryData allCategories = new CategoryData();
			APICall api = new APICall();
			allCategories = api.getAllCategories();
			
			return allCategories;
		}
		
		@Override
		protected void onPostExecute(CategoryData result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			
			if(result != null){
				if(result.isError()) {
					Toast.makeText(MainActivity.this, "Error in result", Toast.LENGTH_SHORT).show();
				}else{
					categories = result;
				}
			}else{
				Toast.makeText(MainActivity.this, "Result is null", Toast.LENGTH_SHORT).show();
			}
			
			for (Category c : categories.getCategories()) {
				//Toast.makeText(MainActivity.this, c.getCategoryName(), Toast.LENGTH_SHORT).show();
				items.add(c.getCategoryName());
			}
			
			adapter.notifyDataSetChanged();
			
			dialog.dismiss();
			
		}
		
		
	}
	
	
	
	
	

}
