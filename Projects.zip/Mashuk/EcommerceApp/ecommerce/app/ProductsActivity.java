package com.ecommerce.app;

import java.util.ArrayList;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.ecommerce.api.APICall;
import com.ecommerce.data.ProductData;
import com.ecommerce.tables.Product;
import com.squareup.picasso.Picasso;

public class ProductsActivity extends Activity{
	
	private String catId;
	private Bundle extra;
	private ProductData products;
	
	private ArrayList<Product> productItems;
	
	private ProductAdapter adapter;
	
	private ListView list;
	
	
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.products);
		
		extra = getIntent().getExtras();
		
		catId = extra.getString("catId");		
		
		products = new ProductData();
		
		productItems = new ArrayList<Product>();
		
		adapter = new ProductAdapter();
		
		list = (ListView) findViewById(R.id.listView1);
		
		list.setAdapter(adapter);
		
		list.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				Toast.makeText(ProductsActivity.this, productItems.get(arg2).getProductName(), Toast.LENGTH_SHORT).show();
				
			}
		});
		
		
		
		new GetAllProducts().execute();
	
	}
	
	// Async task class for getting products in background
	
	private class GetAllProducts extends AsyncTask<Void, Void, ProductData> {

		private ProgressDialog dialog;
		
		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			dialog = new ProgressDialog(ProductsActivity.this);
			dialog.setMessage("Loading Products...!");
		//	dialog.setTitle("Products");
		//	dialog.setIcon(R.drawable.ic_launcher);
			dialog.show();
			super.onPreExecute();
		}

		@Override
		protected ProductData doInBackground(Void... params) {
			// TODO Auto-generated method stub
			
			ProductData data = new ProductData();
			
			APICall api = new APICall();
			data = api.getAllProducts(catId);
			
			return data;
		}
		
		@Override
		protected void onPostExecute(ProductData result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			
			if(result != null) {
				products = result;
			}else{
				Toast.makeText(ProductsActivity.this, "No products found", Toast.LENGTH_SHORT).show();
			}
			
			for(Product p : products.getProducts()) {
				productItems.add(p);
			}
			
			adapter.notifyDataSetChanged();
			
			dialog.dismiss();
		}
	}
	
	// Async task finish
	
	// product adapter start
	
	private class ProductAdapter extends BaseAdapter {

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return productItems.size();
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return productItems.get(position);
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public View getView(final int position, View convertView, ViewGroup parent) {
			// TODO Auto-generated method stub
			ViewHolder holder = null;
			
			if(convertView == null) {
			
			convertView = getLayoutInflater().inflate(R.layout.product_item, parent, false);
			
			holder = new ViewHolder();
			
			holder.thumbnail = (ImageView)  convertView.findViewById(R.id.thumbnail);
			holder.title = (TextView) convertView.findViewById(R.id.productName);
			holder.desc = (TextView) convertView.findViewById(R.id.description);
			holder.price = (TextView) convertView.findViewById(R.id.price);
			
			convertView.setTag(holder);
			}
			else{
				holder = (ViewHolder) convertView.getTag();
			}
			
			Picasso.with(ProductsActivity.this).load(productItems.get(position).getProductImage() ).into(holder.thumbnail);
			
			holder.title.setText( productItems.get(position).getProductName()  );
			holder.desc.setText( productItems.get(position).getDescription());
			holder.price.setText( productItems.get(position).getPrice());
			
			holder.thumbnail.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Toast.makeText(ProductsActivity.this, productItems.get(position).getProductImage(), Toast.LENGTH_SHORT).show();
				}
			});
			
			return convertView;
		}
		
	}
	
	// product adapter finish
	
	public static class ViewHolder {
		
		ImageView thumbnail;
		TextView title;
		TextView desc;
		TextView price;
		
	}
	

}
