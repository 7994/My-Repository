package com.ecommerce.api;

import android.util.Log;

import com.ecommerce.data.CategoryData;
import com.ecommerce.data.ProductData;
import com.google.gson.Gson;


public class APICall {
	
	public CategoryData getAllCategories () {
		
		CategoryData data = new CategoryData();
		String result = null;
		String url = APIResources.BASE_URL + APIResources.GET_CATEGORY;
		
		try {
			 result = HTTPCall.getData(url);
			 Log.d("HTTP Response", result);
			 data = new Gson().fromJson(result, CategoryData.class);
				data.setError(false);
		} catch (Exception e) {
			// TODO: handle exception
			data.setError(true);
			Log.d(" Exception", e.getMessage());
		}
		
		return data;
	}
	
	
	public ProductData getAllProducts(String catId) {
		
		ProductData data = new ProductData();
		String result = null;
		
		String url = APIResources.BASE_URL + APIResources.GET_PRODUCTS + catId;
		
		try {
			result = HTTPCall.getData(url);
			 Log.d("HTTP Response", result);
			 data = new Gson().fromJson(result, ProductData.class);
			 
		} catch (Exception e) {
			// TODO: handle exception
			Log.d("Product Exception", e.getMessage());
			data = null;
		}
		return data;
		
	}

}
