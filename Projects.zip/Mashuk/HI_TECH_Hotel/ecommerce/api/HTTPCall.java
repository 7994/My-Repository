package com.ecommerce.api;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import android.util.Log;

public class HTTPCall {

	public static String getData(String url) {
		
		String result = null;
		
		try {
			
			HttpClient httpClient = new DefaultHttpClient();
			
			HttpGet request = new HttpGet(url);
			
			HttpResponse response = httpClient.execute(request);
			
		    InputStream content =	response.getEntity().getContent();
		    
		    result =  converStreamToSting(content);
		    
			
		} catch (ClientProtocolException e) {
			// TODO Auto-generated catch block
			Log.d("HTTP Protocol", e.getMessage());
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			Log.d("IO Exception ", e.getMessage());
			e.printStackTrace();
		}
		
		return result;
	}
	
	
	
	public static String converStreamToSting(InputStream content) {
		String result = null;
		
		BufferedReader reader;
		
		try {
			reader = new BufferedReader(new InputStreamReader(content, "UTF-8"));
			
			StringBuilder builder = new StringBuilder();

			
			String line = null;
			
			while ((line = reader.readLine()) != null) {
				builder.append(line + "\n");
			}
			
			result = builder.toString();
			
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
	}
	
}
