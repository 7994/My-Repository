package com.ecommerce.data;
import java.util.List;

import com.ecommerce.tables.Category;


public class CategoryData {
	private boolean error;
	private List<Category> categories;

	
	
	public boolean isError() {
		return error;
	}

	public void setError(boolean error) {
		this.error = error;
	}

	public List<Category> getCategories() {
		return categories;
	}

	public void setCategories(List<Category> categories) {
		this.categories = categories;
	}

}
