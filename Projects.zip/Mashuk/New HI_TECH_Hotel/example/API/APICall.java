package com.example.API;

import java.util.ArrayList;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import com.example.Data.CategoryData;
import com.example.Data.ProductData;
import com.google.gson.Gson;

import android.util.Log;

public class APICall {
	
// For Adding Category

	public void addcategory(String name){
		
		Log.d("Category Name", name);
		
		String url = APIResources.BASE_URL+APIResources.ADD_CATEGORY;
		
		ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
		nameValuePairs.add(new BasicNameValuePair("cname", name));
		
		HTTPCall.postData(url, nameValuePairs);
		
	}

// For Adding Product
	
	public void addproduct(String name, String descrip, String price, String categoryid, String image){
		
		Log.d("Product Name", name);
		
		String url = APIResources.BASE_URL+APIResources.ADD_PRODUCT;
		
		ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
		nameValuePairs.add(new BasicNameValuePair("pname", name));
		nameValuePairs.add(new BasicNameValuePair("desc", descrip));
		nameValuePairs.add(new BasicNameValuePair("price", price));
		nameValuePairs.add(new BasicNameValuePair("categoid", categoryid));
		nameValuePairs.add(new BasicNameValuePair("image", image));
		
		HTTPCall.postData(url, nameValuePairs);
		
	}
	
	
	public CategoryData getAllCategories(){
		CategoryData data = new CategoryData();
		String result = null;
		String url = APIResources.BASE_URL+APIResources.GET_CATEGORY;
		
		try {
			result = HTTPCall.getData(url);
			Log.d("HTTP Response", result);
			data = new Gson().fromJson(result, CategoryData.class);
			data.setError(false);
			
			
		} catch (Exception e) {
			// TODO: handle exception
			data.setError(true);
		}
		return data;
		
	}

	
	public ProductData getAllProducts(String catId) {
		
		ProductData data = new ProductData();
		String result = null;
		
		String url = APIResources.BASE_URL + APIResources.GET_PRODUCT + catId;
		
		try {
			result = HTTPCall.getData(url);
			 Log.d("HTTP Response", result);
			 data = new Gson().fromJson(result, ProductData.class);
			 
		} catch (Exception e) {
			// TODO: handle exception
			Log.d("Product Exception", e.getMessage());
			data = null;
		}
		return data;
		
	}
	
}
