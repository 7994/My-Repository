package com.example.API;

public class APIResources {
	
	public static final String BASE_URL = "http://115.117.231.87:81/New_HI-TechHotel/";
	public static final String ADD_CATEGORY = "addCategory.php";
	public static final String ADD_PRODUCT = "addProduct.php";
	public static final String GET_CATEGORY = "getCategory.php";
	public static final String GET_PRODUCT = "getProduct.php?catId=";
	
}
