package com.example.Data;

import java.util.List;

import com.example.Tables.Product;

public class ProductData {
	
	private List<Product> products;

	public List<Product> getProducts() {
		return products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}
	

}
