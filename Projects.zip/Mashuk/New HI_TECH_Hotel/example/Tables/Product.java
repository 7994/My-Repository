package com.example.Tables;

public class Product {
	
	private String product_Id;
	private String product_Name;
	private String description;
	private String price;
	private String category_Id;
	private String product_Image;
	public String getProduct_Id() {
		return product_Id;
	}
	public void setProduct_Id(String product_Id) {
		this.product_Id = product_Id;
	}
	public String getProduct_Name() {
		return product_Name;
	}
	public void setProduct_Name(String product_Name) {
		this.product_Name = product_Name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getCategory_Id() {
		return category_Id;
	}
	public void setCategory_Id(String category_Id) {
		this.category_Id = category_Id;
	}
	public String getProduct_Image() {
		return product_Image;
	}
	public void setProduct_Image(String product_Image) {
		this.product_Image = product_Image;
	}
	

}
