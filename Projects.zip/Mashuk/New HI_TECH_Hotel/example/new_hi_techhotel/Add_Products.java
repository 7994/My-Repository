package com.example.new_hi_techhotel;

import com.example.API.APICall;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Add_Products extends Activity {
	private EditText etPname;
	private EditText etDescription;
	private EditText etPrice;
	private EditText etCatid;
	private EditText etImage;
	private Button btnAddProd;
	String prodname,descri, price, cateid, image;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_addproduct);
		
		etPname = (EditText)findViewById(R.id.etPName);
		etDescription = (EditText)findViewById(R.id.etDescription);
		etPrice = (EditText)findViewById(R.id.etPrice);
		etCatid = (EditText)findViewById(R.id.etCatId);
		etImage = (EditText)findViewById(R.id.etImage);
		btnAddProd = (Button)findViewById(R.id.btnAddProd);
		
		btnAddProd.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				prodname = etPname.getText().toString().trim();
				descri = etPname.getText().toString().trim();
				price = etPname.getText().toString().trim();
				cateid = etPname.getText().toString().trim();
				image = etPname.getText().toString().trim();
				
				Toast.makeText(Add_Products.this , "Product Name "+ prodname, Toast.LENGTH_SHORT).show();
				etPname.setText("");
				etDescription.setText("");
				etPrice.setText("");
				etCatid.setText("");
				etImage.setText("");
				
				new AddPro().execute();
				
			}
		});
		
	}

	
	private class AddPro extends AsyncTask<Void, Void, Void>{

		@Override
		protected Void doInBackground(Void... params) {
			// TODO Auto-generated method stub
			
			APICall api = new APICall();
			api.addproduct(prodname, descri, price, cateid, image);
			
			return null;
		}
		
		@Override
		protected void onPostExecute(Void result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
		}
	}
}
