package com.example.new_hi_techhotel;

import java.util.ArrayList;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import com.example.API.APICall;
import com.example.Data.CategoryData;
import com.example.Tables.Category;

public class Customer extends Activity{

	private ListView list;
	private CategoryData categories;
	private ArrayList<String> items;
	private ArrayAdapter<String> adapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_customer);
		
		categories = new CategoryData();
		items = new ArrayList<String>();
		
		adapter = new ArrayAdapter<String>(Customer.this, android.R.layout.simple_list_item_1, items);
		
		list = (ListView)findViewById(R.id.listCat);
		list.setAdapter(adapter);
		
		list.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				Toast.makeText(Customer.this, categories.getCategories().get(arg2).getCategory_Id(), Toast.LENGTH_SHORT).show();
				String catId = categories.getCategories().get(arg2).getCategory_Id();
				
				Intent products = new Intent(Customer.this, ProductsActivity.class);
				products.putExtra("catId", catId);
				startActivity(products);
				
			}
		});
		
		new GetAllCategories().execute();
		
	}
	
	private class GetAllCategories extends AsyncTask<Void, Void, CategoryData>{

		private ProgressDialog dialog;

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			dialog = new ProgressDialog(Customer.this);
			dialog.setMessage("Loading..");
			dialog.setTitle("Categories");
			dialog.setIcon(R.drawable.ic_launcher);
			dialog.show();
			super.onPreExecute();
		}
		
		@Override
		protected CategoryData doInBackground(Void... params) {
			// TODO Auto-generated method stub
			CategoryData allCategories = new CategoryData();
			APICall api = new APICall();
			allCategories = api.getAllCategories();
			return allCategories;
		}
		
		@Override
		protected void onPostExecute(CategoryData result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			
			if(result != null){
				if(result.isError()){
					Toast.makeText(Customer.this, "Error in Result", Toast.LENGTH_SHORT).show();
				}
				
				else {
					categories = result;
				}
			}
			
			else {
				Toast.makeText(Customer.this, "Result is Null", Toast.LENGTH_SHORT).show();
			}
			
			for(Category c: categories.getCategories()){
				
				items.add(c.getCategory_Name());
			}
			
			adapter.notifyDataSetChanged();
			dialog.dismiss();
		}
		
	}

}
