package com.example.new_hi_techhotel;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class Start extends Activity {
	
	private Button btnAdmin;
	private Button btnCustomer;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.start);
		
		btnAdmin = (Button)findViewById(R.id.btnAdmin);
		btnCustomer = (Button)findViewById(R.id.btnCustomer);
		
		btnAdmin.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				Intent admin = new Intent(Start.this, Admin.class);
				startActivity(admin);
			}
		});
		
		btnCustomer.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				Intent customer = new Intent(Start.this, Customer.class);
				startActivity(customer);
				
			}
		});
		
	}

}
