package com.example.persondata;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {

	private EditText name;
	private EditText email;
	private EditText number;
	private Button btnSave;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		
		//ids
		name=(EditText)findViewById(R.id.editName);
		email=(EditText)findViewById(R.id.editEmail);
		number=(EditText)findViewById(R.id.editPhone);
		
		btnSave=(Button)findViewById(R.id.btnSave);
		
		
		btnSave.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				String pname=name.getText().toString().trim();
				String pemail=email.getText().toString().trim();
				String pnumber=number.getText().toString().trim();
				
				
				PersonDB person=new PersonDB(MainActivity.this);
				person.open();
				
				double id=person.insertdata(pname, pemail, pnumber);
				
				person.close();
				
				if(id==-1){
					Toast.makeText(MainActivity.this, "Data not inserted", Toast.LENGTH_SHORT).show();
				}
				else{
					Toast.makeText(MainActivity.this, "Data inserted"+id, Toast.LENGTH_SHORT).show();
				}
				
				
				
				
			}
		});
		
	}

	

}
