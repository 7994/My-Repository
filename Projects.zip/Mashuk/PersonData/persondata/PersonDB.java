package com.example.persondata;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class PersonDB {
	
	private static final String KEY_NAME="person_name";
	private static final String KEY_EMAIL="person_email";
	private static final String KEY_NUMBER="person_number";
	
	
	private static final String DATABASE_NAME="PersonDB";
	private static final String DATABASE_TABLE="PersonData";
	
	private static final int DATABASE_VERSION=2;
	
	
	//Usefull objects
	private final Context ourContext;
	private DBHelper ourHelper;
	private SQLiteDatabase ourDatabase;
	
	
	
	public PersonDB(Context context){
		this.ourContext=context;
	}
	private class DBHelper extends SQLiteOpenHelper{

		public DBHelper(Context context) {
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
			// TODO Auto-generated constructor stub
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			// TODO Auto-generated method stub
			
			
			
			
			
			
			String query="CREATE TABLE IF NOT EXISTS "+DATABASE_TABLE+
					" ( "+KEY_NAME+" TEXT NOT NULL, "+KEY_EMAIL+" TEXT NOT NULL, "
					+KEY_NUMBER+" TEXT NOT NULL); ";
			Log.d("SQLQUERY", query);
			
			db.execSQL(query);
			
			
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			// TODO Auto-generated method stub
			
			db.execSQL("DROP TABLE IF EXISTS "+DATABASE_TABLE);
			onCreate(db);
					
			
		}
		
	}
	
	public PersonDB open(){
			
		ourHelper=new DBHelper(ourContext);
		ourDatabase=ourHelper.getWritableDatabase();
		return this;
		
	}
	public void close(){
		ourHelper.close();
	}
	public double insertdata(String name,String email,String number){
		
		ContentValues values=new ContentValues();
		
		values.put(KEY_NAME, name);
		values.put(KEY_EMAIL, email);
		values.put(KEY_NUMBER, number);
		
		return ourDatabase.insert(DATABASE_TABLE, null, values);
		
		
		
	}
	
	
	

}
