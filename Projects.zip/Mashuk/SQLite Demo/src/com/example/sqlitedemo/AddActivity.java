package com.example.sqlitedemo;

import Database.ProductDB;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddActivity extends Activity{
private EditText editname;
private EditText editqty;
private EditText editprice;
private Button btnadd;

@Override
protected void onCreate(Bundle savedInstanceState) {
	// TODO Auto-generated method stub
	super.onCreate(savedInstanceState);
	setContentView(R.layout.activity_add);
	
	//Ids
	editname=(EditText)findViewById(R.id.editProductName);
	editqty=(EditText)findViewById(R.id.editProductQty);
	editprice=(EditText)findViewById(R.id.editProductPrice);
	
	btnadd=(Button)findViewById(R.id.btnAdd);
	
	
	btnadd.setOnClickListener(new OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			String name=editname.getText().toString().trim();
			String qty=editqty.getText().toString().trim();
			String price=editprice.getText().toString().trim();
			
			ProductDB db=new ProductDB(AddActivity.this);
			db.open();
			long id=db.insert(name, qty, price);
			
			db.close();
			if(id==-1){
				Toast.makeText(AddActivity.this, "Data not Inserted", Toast.LENGTH_SHORT).show();
			}
			else{
				Toast.makeText(AddActivity.this, "Data Inserted:"+id, Toast.LENGTH_SHORT).show();
			}
			editname.setText("");
			editqty.setText("");
			editprice.setText("");
		}
	});
	
	
}
}
