package com.example.sqlitedemo;

import java.util.ArrayList;

import pojo.Product;

import Database.ProductDB;
import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class AllProductActivity extends Activity {

	private ListView list;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_allproduct);
		list=(ListView)findViewById(R.id.listView1);
		
		ArrayList<String> listdata=new ArrayList<String>();
		ArrayAdapter<String> adapter=new ArrayAdapter<String>(AllProductActivity.this, android.R.layout.simple_list_item_1, listdata);
		list.setAdapter(adapter);
		
		ProductDB db=new ProductDB(AllProductActivity.this);
		db.open();
		ArrayList<Product> product=new ArrayList<Product>();
		
		product=db.getALLProduct();
		
		db.close();
		
		for(Product p:product){
			listdata.add(p.getPname());
		}
		adapter.notifyDataSetChanged();
	}
}
