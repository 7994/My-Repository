package com.example.sqlitedemo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity extends Activity {

	private Button btnadd;
	private Button btnshow;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		//button Ids
		
		btnadd=(Button)findViewById(R.id.btnAdd);
		btnshow=(Button)findViewById(R.id.btnShow);
		
		btnadd.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent i=new Intent(MainActivity.this, AddActivity.class);
				startActivity(i);
			}
		});
		
		btnshow.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent j=new Intent(MainActivity.this, AllProductActivity.class);
				startActivity(j)
;			}
		});
	}

	

}
