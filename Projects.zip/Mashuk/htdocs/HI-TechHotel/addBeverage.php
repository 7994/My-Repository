<?php

//Getting Data

$name = $_POST['Bname'];
$descrp = $_POST['Bdesc'];
$price = $_POST['Bprice'];
$image = $_POST['Bimage'];


//$name = "HardDisk";
//$qty = "4";
//$price = "5000";


//Open connection
$conn=mysqli_connect("localhost","root","","hi_techhotel");

if(!$conn)
{
trigger_error('could not connect '.mysqli_connect_error());
}

//Insert query
$sql="INSERT INTO add_beverages(beverage_Name, beverage_Description, beverage_Price, beverage_Image ) VALUES ('$name', '$descrp', '$price', '$image')";

//Query fire

if($conn->query($sql)===TRUE){
$flag[ 'code' ] ="1";

//echo "Data added successfully";
}

else{
$flag[ 'code' ] ="0";
//echo "Error in adding data---".$conn->error;
}

print(json_encode($flag));

//Connection close
$conn->close();
?>