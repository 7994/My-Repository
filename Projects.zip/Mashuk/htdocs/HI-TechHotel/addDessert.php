<?php

$name = $_POST['DessertName'];
$price = $_POST['DessertPrice'];
$image = $_POST['DessertImage'];



$conn=mysqli_connect("localhost","root","","hi_techhotel");

if(!$conn)
{
trigger_error('could not connect '.mysqli_connect_error());
}

$sql="INSERT INTO add_desserts(dessert_Name, dessert_Price, dessert_Image ) VALUES('$name', '$price', '$image')";


if($conn->query($sql)===TRUE){
$flag[ 'code' ] ="1";
}

else{
$flag[ 'code' ] ="0";
}

print(json_encode($flag));
$conn->close();
?>