<?php

$name = $_POST['StarterName'];
$price = $_POST['StarterPrice'];
$image = $_POST['StarterImage'];



$conn=mysqli_connect("localhost","root","","hi_techhotel");

if(!$conn)
{
trigger_error('could not connect '.mysqli_connect_error());
}

$sql="INSERT INTO add_starters(starter_Name, starter_Price, starter_Image ) VALUES('$name', '$price', '$image')";


if($conn->query($sql)===TRUE){
$flag[ 'code' ] ="1";
}

else{
$flag[ 'code' ] ="0";
}

print(json_encode($flag));
$conn->close();
?>