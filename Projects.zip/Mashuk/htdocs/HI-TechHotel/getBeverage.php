<?php

//$drinkId = $_GET['drinkId'];
$drinkId = $_POST['drinkId'];	

	$conn = mysqli_connect("localhost","root","","hi_techhotel");
	$select = mysqli_query($conn,"SELECT * FROM add_beverages WHERE beverage_Id = ".$drinkId."");
	$array = '';
	while($rws = mysqli_fetch_assoc($select))
	{
		$array["drinks"][]  = $rws;
	}
	echo json_encode($array);
	die;
?>