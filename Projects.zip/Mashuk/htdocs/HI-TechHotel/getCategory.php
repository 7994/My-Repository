<?php
	$conn = mysqli_connect("localhost", "root", "", "hi_techhotel");
	$select = mysqli_query($conn, "SELECT * FROM add_category");
	$array = '';
	while($rws = mysqli_fetch_assoc($select)){
		$array["categories"][] = $rws;
	}
	echo json_encode($array);
	die;
?>