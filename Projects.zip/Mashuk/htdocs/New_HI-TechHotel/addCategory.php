<?php

//Getting Data
	$name = $_POST['cname'];
	
//Open Connection
	$conn = mysqli_connect("localhost", "root", "", "new_hi_techhotel");

		if(!$conn){
			trigger_error('Could not Connect'.mysqli_connect_error);
		}
	
//Insert Query
	$sql = "INSERT INTO category(category_Name) VALUES('$name')";
	
//Query Fire
	if($conn->query($sql)==TRUE){
		$flag['code'] = "1";
	}
	
	else{
		$flag['code'] = "0";
	}
	
	print(json_encode($flag));
	
//Close Connection
	$conn->close();
	

?>