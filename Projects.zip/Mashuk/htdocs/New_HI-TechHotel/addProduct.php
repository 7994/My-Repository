<?php

//Getting Data

	$name = $_POST['pname'];
	$desc = $_POST['image'];
	$price = $_POST['price'];
	$categoryId = $_POST['categoid'];
	$image = $_POST['image'];

//	$desc = $_POST['desc'];
//	$price = $_POST['price'];
//	$categoryid = $_POST['categoid'];
//	$image = $_POST['image'];

//Open Connection
	$conn = mysqli_connect("localhost","root","","new_hi_techhotel");
	
	if(!$conn){
		trigger_error('Could not Connect'.mysqli_connect_error);
	}

//Insert Query
	$sql = "INSERT INTO product(product_Name, description, price, category_Id, product_Image) VALUES ('$name', '$desc', '$price', '$categoryId', '$image')";  

//Query Fire
	if($conn->query($sql)==TRUE){
		$flag['code'] = "1";
	}
	
	else{
		$flag['code'] = "0";
	}
	
	print(json_encode($flag));

//Close Connection
	$conn->close();

?>


	