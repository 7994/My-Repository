<?php
	$conn = mysqli_connect("localhost", "root", "", "new_hi_techhotel");
	$select = mysqli_query($conn, "SELECT * FROM category");
	$array = '';
	while($rws = mysqli_fetch_assoc($select)){
		$array["categories"][] = $rws;
	}
	echo json_encode($array);
	die;
?>