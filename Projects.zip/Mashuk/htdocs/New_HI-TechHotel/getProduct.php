<?php

$catId = $_GET['catId'];
//$catId = $_POST['catId'];	

	$conn = mysqli_connect("localhost","root","","new_hi_techhotel");
	$select = mysqli_query($conn,"SELECT * FROM product WHERE category_Id = ".$catId."");
	$array = '';
	while($rws = mysqli_fetch_assoc($select))
	{
		$array["products"][]  = $rws;
	}
	echo json_encode($array);
	die;
?>

