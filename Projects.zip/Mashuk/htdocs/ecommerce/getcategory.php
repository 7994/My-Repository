<?php
	$conn = mysqli_connect("localhost","root","","ecommerce");
	$select = mysqli_query($conn,"SELECT * FROM category");
	$array = '';	
	while($rws = mysqli_fetch_assoc($select))
	{
		$array["categories"][]  = $rws;
	}
	echo json_encode($array);
	die;
?>