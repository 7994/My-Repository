<?php

$catId = $_GET['catId'];
//$catId = $_POST['catId'];	

	$conn = mysqli_connect("localhost","root","","ecommerce");
	$select = mysqli_query($conn,"SELECT * FROM product WHERE categoryId = ".$catId."");
	$array = '';
	while($rws = mysqli_fetch_assoc($select))
	{
		$array["products"][]  = $rws;
	}
	echo json_encode($array);
	die;
?>

