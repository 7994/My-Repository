<?php
//Open Connection

$catId = $_GET['catId'];
//$catId = $_POST['catId'];	

$conn = mysqli_connect("localhost","root","","ecommerce");
if(!$conn)
{
	trigger_error('Could not Connect' .mysqli_connect_error());
}

//Fetch table rows
$sql = "SELECT * FROM product";
$result = mysqli_query($conn, $sql);

//Create an array
$array = array();

while($row=mysqli_fetch_assoc($result))
{
	$array[] = $row;
}

echo'{"ProductsData":'.json_encode($array).'}';
mysqli_close('$conn');
?>