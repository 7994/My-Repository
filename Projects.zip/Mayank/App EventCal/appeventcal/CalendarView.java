package com.example.appeventcal;


import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Locale;

import android.R.color;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;

import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

@SuppressLint({ "ResourceAsColor", "InlinedApi" }) public class CalendarView extends Activity {

	private ListView list;
	private ArrayList<String> listdata;
	private ArrayAdapter<String> arrayadapter;
	private ArrayList<EventPojo> eventlistdetail;
	public GregorianCalendar month, itemmonth;// calendar instances.

	public CalendarAdapter adapter;// adapter instance
	public Handler handler;// for grabbing some event values for showing the dot
							// marker.
	public ArrayList<String> items; // container to store calendar items which
									// needs showing the event marker
	private TextView Noevent;

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		if(requestCode==2){
			Bundle e=data.getExtras();

			String m=e.getString("month");
			String y=e.getString("year");
			
			read(m.trim(), y.trim());

		}
	}
	@Override
	@SuppressLint("SimpleDateFormat") public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.calendar);
		
		 Locale.setDefault( Locale.US );
		month = (GregorianCalendar) GregorianCalendar.getInstance();
		itemmonth = (GregorianCalendar) month.clone();

		items = new ArrayList<String>();
		adapter = new CalendarAdapter(this, month);

		GridView gridview = (GridView) findViewById(R.id.gridview);
		
		gridview.setAdapter(adapter);

		handler = new Handler();
	//	handler.post(calendarUpdater);

		TextView title = (TextView) findViewById(R.id.title);
		title.setText(android.text.format.DateFormat.format("MMMM yyyy", month));

		RelativeLayout previous = (RelativeLayout) findViewById(R.id.previous);

		previous.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				setPreviousMonth();
				refreshCalendar(month);
			}
		});

		RelativeLayout next = (RelativeLayout) findViewById(R.id.next);
		next.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				setNextMonth();
				refreshCalendar(month);

			}
		});

		gridview.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> parent, View v,
					int position, long id) {

				((CalendarAdapter) parent.getAdapter()).setSelected(v);
				String selectedGridDate = CalendarAdapter.dayString
						.get(position);
				String[] separatedTime = selectedGridDate.split("-");
				String gridvalueString = separatedTime[2].replaceFirst("^0*",
						"");// taking last part of date. ie; 2 from 2012-12-02.
				int gridvalue = Integer.parseInt(gridvalueString);
				// navigate to next or previous month on clicking offdays.
				if ((gridvalue > 10) && (position < 8)) {
					setPreviousMonth();
					refreshCalendar(month);
				} else if ((gridvalue < 7) && (position > 28)) {
					setNextMonth();
					refreshCalendar(month);
				}
				((CalendarAdapter) parent.getAdapter()).setSelected(v);

				//spliting the date to pass day month and year through Intent
				String date=selectedGridDate;
				String monthdate=date.substring(date.indexOf("-")+1);
				
				String year=date.substring(0, date.indexOf("-")).trim();
				String month1=date.substring(date.indexOf("-")+1, date.indexOf("-")+3).trim();
				String day=monthdate.substring(monthdate.indexOf("-")+1).trim();
				
				
				//Intent to go on next activity
				
				Intent i=new Intent(CalendarView.this, EventAdd.class);
				i.putExtra("year", year.trim());
				i.putExtra("month", month1.trim());
				i.putExtra("day", day.trim());
				
				startActivityForResult(i, 2);
				
			

			}
		});
		
		
		
		Calendar date = Calendar.getInstance();       
        // for your date format use
        SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyy");        
        // set a string to format your current date
        String curDate = sdf.format(date.getTime());
        String curMonth=curDate.substring(2, 4);
        String curYear=curDate.substring(4);
      
     
        
        //call read method
        read(curMonth, curYear);
		
	
	}
	

	protected void setNextMonth() {
		if (month.get(GregorianCalendar.MONTH) == month
				.getActualMaximum(GregorianCalendar.MONTH)) {
			month.set((month.get(GregorianCalendar.YEAR) + 1),
					month.getActualMinimum(GregorianCalendar.MONTH), 1);
		} else {
			month.set(GregorianCalendar.MONTH,
					month.get(GregorianCalendar.MONTH) + 1);
		}
		
	}

	protected void setPreviousMonth() {
		if (month.get(GregorianCalendar.MONTH) == month
				.getActualMinimum(GregorianCalendar.MONTH)) {
			month.set((month.get(GregorianCalendar.YEAR) - 1),
					month.getActualMaximum(GregorianCalendar.MONTH), 1);
		} else {
			month.set(GregorianCalendar.MONTH,
					month.get(GregorianCalendar.MONTH) - 1);
		}
			
	}

	protected void showToast(String string) {
		Toast.makeText(this, string, Toast.LENGTH_SHORT).show();

	}

	public void refreshCalendar(Calendar mahino) {
		TextView title = (TextView) findViewById(R.id.title);

		adapter.refreshDays();
		adapter.notifyDataSetChanged();
//		handler.post(calendarUpdater); // generate some calendar items

		title.setText(android.text.format.DateFormat.format("MMMM yyyy", mahino));
		String a=title.getText().toString().trim();
		String b=a.substring(0, a.indexOf(" "));
		String c=a.substring(a.indexOf(" "));
		
		
		String d=null;
		if(b.equals("January")){
			d="01";
		}
		if(b.equals("February")){
			d="02";
		}
		if(b.equals("March")){
			d="03";
		}
		if(b.equals("April")){
			d="04";
		}
		if(b.equals("May")){
			d="05";
		}
		if(b.equals("June")){
			d="06";
		}
		if(b.equals("July")){
			d="07";
		}
		if(b.equals("August")){
			d="08";
		}
		if(b.equals("September")){
			d="09";
		}
		if(b.equals("October")){
			d="10";
		}
		if(b.equals("November")){
			d="11";
		}
		if(b.equals("December")){
			d="12";
		}
	
		read(d.trim(), c.trim());
		
	}

	public void read(String month1,String year){
		
		EventDB db=new EventDB(CalendarView.this);
		ArrayList<EventPojo> eventlist=new ArrayList<EventPojo>();
		eventlistdetail=new ArrayList<EventPojo>();
		
		listdata=new ArrayList<String>();
		list=(ListView)findViewById(R.id.listeventName);
		
		
		String yearmonth=year+month1;
		db.open();
		eventlist=db.readAllEvent(yearmonth);
		eventlistdetail=eventlist;
		db.close();
		Noevent=(TextView)findViewById(R.id.txtNoEvent);
		if(eventlist.isEmpty()){
			
			Noevent.setText("No events.");
			listdata.add("");
			list.setBackgroundColor(android.R.color.white);
			list.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> arg0, View arg1,
						int arg2, long arg3) {
					// TODO Auto-generated method stub
					//No action on clck
				}
			});
		}
		
		else{
		Noevent.setText("");
		list.setBackgroundColor(Color.TRANSPARENT);
		
		for(EventPojo e:eventlist){
			listdata.add(e.getDay()+".  "+e.getEventname());
			
		}
		
		
		//Listitem click listener
  		list.setOnItemClickListener(new OnItemClickListener() {

  			@Override
  			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
  					long arg3) {
  				// TODO Auto-generated method stub
  				int position =arg2;
  				EventPojo p=eventlistdetail.get(position);
  				
  				String d=p.getDay();
  				String m=p.getMonth();
  				String y=p.getYear();
  				String regdate=d+"/"+m+"/"+y;
  				
  				
  				Intent j=new Intent(getApplicationContext(), EventDetail.class);
  				j.putExtra("rowid", p.getRow_Id());
  				j.putExtra("ename", p.getEventname());
  				j.putExtra("cname", p.getClientname());
  				j.putExtra("mobileno", p.getMobileno());
  				j.putExtra("email", p.getEmail());
  				j.putExtra("address", p.getAddress());
  				j.putExtra("sdate", p.getStartdate());
  				j.putExtra("edate", p.getEnddate());
  				j.putExtra("regdate", regdate);
  				
  				j.putExtra("day", d);
  				j.putExtra("month", m);
  				j.putExtra("year",y);
  				//startActivity(j);
  				startActivityForResult(j, 2);
  			}
  		});
		
		
		
		
		}
		arrayadapter=new ArrayAdapter<String>(CalendarView.this, android.R.layout.simple_list_item_1, listdata);
		
		list.setAdapter(arrayadapter);
		arrayadapter.notifyDataSetChanged();
		
		
	
	}
		
		
		
	}


