package com.example.appeventcal;





import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DatePickerDialog;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;


@SuppressLint("CutPasteId") public class EventAdd extends Activity{
	
	private TextView startDateDisplay;
	private TextView endDateDisplay;
	
	public DatePickerDialog dia;

    static final int DATE_DIALOG_ID = 0;

    private TextView activeDateDisplay;
    
    private String activeDay;
    private String activeMonth;
    private String activeYear;
    
	String year;
	String month;
	String day;
	private EditText editeventname;
	private EditText editclientname;
	private EditText editmobileno;
	private EditText editaddress;
	private EditText editemail;
	private TextView txtstartdate;
	private TextView txtenddate;
	private Button btnSave;
	private ImageButton btnBack;
	private String regday;
	private String regmonth;
	private String regyear;
	private String regyearmonth;
	
	
	@Override
	public boolean onKeyUp(int keyCode, KeyEvent event) {
		// TODO Auto-generated method stub
		if(keyCode==KeyEvent.KEYCODE_BACK){
			Intent r=new Intent();
			r.putExtra("day", regday);
			r.putExtra("month", regmonth);
			r.putExtra("year", regyear);
			setResult(2, r);
			finish();
			return true;
		}
		return super.onKeyUp(keyCode, event);
	}
	
	@SuppressLint("CutPasteId") @Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.eventadd);
		
		//Get intent
		Intent j=getIntent();
		Bundle extra=j.getExtras();
		
		//day month and year of selected date
		year=extra.getString("year").trim();
		month=extra.getString("month").trim();
		day=extra.getString("day").trim();
		
		//EditText ids
		editeventname=(EditText)findViewById(R.id.editeventname);
		editclientname=(EditText)findViewById(R.id.editclientname);
		editmobileno=(EditText)findViewById(R.id.editmobileno);
		editemail=(EditText)findViewById(R.id.editemail);
		editaddress=(EditText)findViewById(R.id.editaddress);
		txtstartdate=(TextView)findViewById(R.id.txtstartdate);
		txtenddate=(TextView)findViewById(R.id.txtenddate);
		//Button ids
		btnSave=(Button)findViewById(R.id.button1);
		btnBack=(ImageButton)findViewById(R.id.imageButton1);
		
		//textview ids for start and and date
		startDateDisplay=(TextView)findViewById(R.id.txtstartdate);
		endDateDisplay=(TextView)findViewById(R.id.txtenddate);
		
		//first set Start and End Date with the selected date by calling bellow method
		updateDisplay(startDateDisplay, day, month, year);
		updateDisplay(endDateDisplay, day, month, year);
		
		
		//Startdate click listener
		startDateDisplay.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				showDateDialog(startDateDisplay);
			}
		});
		//Enddate click listener
		endDateDisplay.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				showDateDialog(endDateDisplay);
			}
		});
		
		
		
		//Data to be stored
		 regday=day;
		 regmonth=month;
		 regyear=year;
		 regyearmonth=year+month;
		
		
		//Button Back click event
		btnBack.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent w=new Intent();
				w.putExtra("day", day);
				w.putExtra("month", month);
				w.putExtra("year", year);
				setResult(2, w);
				finish();
			}
		});
		
				//Button Save click event
		btnSave.setOnClickListener(new OnClickListener() {
			
			

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				final String eventName=editeventname.getText().toString().trim();
				final String clientName=editclientname.getText().toString().trim();
				final String mobileNo=editmobileno.getText().toString().trim();
				final String email=editemail.getText().toString().trim();
				final String address=editaddress.getText().toString().trim();
				final String startDate=txtstartdate.getText().toString().trim();
				final String endDate=txtenddate.getText().toString().trim();

			
					
				
				EventDB db=new EventDB(EventAdd.this);
				db.open();
				long id=db.insertData(eventName, clientName, mobileNo, email, address, startDate, endDate, regday.trim(), regmonth.trim(), regyear.trim(),regyearmonth);
				db.close();
				if(id==-1){
					Toast.makeText(EventAdd.this, "Event not added.Try again",Toast.LENGTH_SHORT ).show();
				}
				else{
					Toast.makeText(EventAdd.this, "Event added successfully ",Toast.LENGTH_SHORT ).show();
				}
				
				
				editeventname.setText("");
				editclientname.setText("");
				editmobileno.setText("");
				editemail.setText("");
				editaddress.setText("");
				
				
			}
		});
		
	                             
		
	}
	//method to assign textview to Active textview
	public void showDateDialog(TextView dateDisplay){
		activeDateDisplay=dateDisplay;
		
		//it will show dialog to select date i.e. datepicker
		DatePickerDialog mDatePicker=new DatePickerDialog(EventAdd.this, new DatePickerDialog.OnDateSetListener() {
			
			@Override
			public void onDateSet(DatePicker view, int year, int monthOfYear,
					int dayOfMonth) {
				// TODO Auto-generated method stub
				activeDay=dayOfMonth+"";
				activeMonth=monthOfYear+1+"";
				activeYear=year+"";
				updateDisplay(activeDateDisplay, activeDay, activeMonth, activeYear);
				unregisterDateDisplay();
				
			}
		}, Integer.parseInt(year), Integer.parseInt(month)-1, Integer.parseInt(day));
		mDatePicker.show();
	}
	
	
	  
	
	//public method to display Start and End Date
	public void updateDisplay(TextView dateDisplay, String d,String m,String y)
	{
        dateDisplay.setText(d+"/"+m+"/"+y);
        }
	//clear the active component
		private void unregisterDateDisplay() {
	        activeDateDisplay = null;
	        activeDay=null;
			activeMonth=null;
			activeYear=null;
	    }
		
}

