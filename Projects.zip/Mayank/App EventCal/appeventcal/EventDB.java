package com.example.appeventcal;


import java.util.ArrayList;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class EventDB {
	
	//Database Details......
	public static final String KEY_ROW_ID="Id";
	public static final String KEY_EVENT_NAME="EventName";
	public static final String KEY_CLIENT_NAME="ClientName";
	public static final String KEY_MOBILE_NO="MobileNo";
	public static final String KEY_EMAIL="Email";
	public static final String KEY_ADDRESS="Address";
	public static final String KEY_STARTDATE="StartDate";
	public static final String KEY_ENDDATE="EndDate";
	public static final String KEY_DAY="Day";
	public static final String KEY_MONTH="Month";
	public static final String KEY_YEAR="Year";
	public static final String KEY_YEARMONTH="YearMonth";
	
	public static final String DATABASE_NAME="EventDB";
	public static final String DATABASE_TABLE="EventData";
	
	public static final int DATABASE_VERSION=1;
	
	public static final String[] columns={KEY_ROW_ID,KEY_EVENT_NAME,KEY_CLIENT_NAME,KEY_MOBILE_NO,KEY_EMAIL,KEY_ADDRESS,KEY_STARTDATE,KEY_ENDDATE,KEY_DAY,KEY_MONTH,KEY_YEAR};
	
	//Constructor of class EventDB
	public EventDB(Context context){
		this.ourContext=context;
	}
	
	
	//Useful objects.................

			private final Context ourContext;
			private DBHelper ourHelper;
			private SQLiteDatabase ourDatabase;
			
			//DBHelper class starts..........
			
			private class DBHelper extends SQLiteOpenHelper{

				public DBHelper(Context context) {
					super(context, DATABASE_NAME, null, DATABASE_VERSION);
					// TODO Auto-generated constructor stub
				}

				@Override
				public void onCreate(SQLiteDatabase db) {
					// TODO Auto-generated method stub
					System.out.println("Going to Create Database");
					String query="CREATE TABLE IF NOT EXISTS "+DATABASE_TABLE+
								   " ("+KEY_ROW_ID+" INTEGER PRIMARY KEY AUTOINCREMENT, "
								    +KEY_EVENT_NAME+" TEXT NOT NULL, "
								    +KEY_CLIENT_NAME+" TEXT NOT NULL, "
								    +KEY_MOBILE_NO+" TEXT NOT NULL, "
								    +KEY_EMAIL+" TEXT NOT NULL, "
								    +KEY_ADDRESS+" TEXT NOT NULL, "
								    +KEY_STARTDATE+" TEXT NOT NULL, "
								    +KEY_ENDDATE+" TEXT NOT NULL, "
								    +KEY_DAY+" TEXT NOT NULL, "
								    +KEY_MONTH+" TEXT NOT NULL, "
								    +KEY_YEARMONTH+" TEXT NOT NULL, "
								    +KEY_YEAR+" TEXT NOT NULL);";
					
					
					Log.d("SQL Query", query);
					System.out.println("Database query is ---");
					db.execSQL(query);
				}

				@Override
				public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
					// TODO Auto-generated method stub
					db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE);
					onCreate(db);
				}
				
			}		
			//DBHelper class Ends............
			
			
			//Database Operations............
			
			//Open DBHelper
			public EventDB open(){
				ourHelper=new DBHelper(ourContext);
				ourDatabase=ourHelper.getWritableDatabase();
				return this;
			}
			//Close DBHelper
			public void close(){
				ourHelper.close();
			}

			//insert data
			public long insertData(String EventName,String ClientName,String MobileNo,String Email,String Address,String StartDate,String EndDate,String Day,String Month,String Year,String yearmonth)
			{
				ContentValues values=new ContentValues();
				
				values.put(KEY_EVENT_NAME, EventName);
				values.put(KEY_CLIENT_NAME, ClientName);
				values.put(KEY_MOBILE_NO, MobileNo);
				values.put(KEY_EMAIL, Email);
				values.put(KEY_ADDRESS, Address);
				values.put(KEY_STARTDATE, StartDate);
				values.put(KEY_ENDDATE, EndDate);
				values.put(KEY_DAY, Day);
				values.put(KEY_MONTH, Month);
				values.put(KEY_YEAR, Year);
				values.put(KEY_YEARMONTH,yearmonth);
			return ourDatabase.insert(DATABASE_TABLE, null, values);	
			}
			
			
			//read all eventname
			public ArrayList<EventPojo> readAllEvent(String ym){
				ArrayList<EventPojo> eventdata=new ArrayList<EventPojo>();
				Cursor c=ourDatabase.query(DATABASE_TABLE,columns , KEY_YEARMONTH+"="+ym, null, null, null, null);
				
				for(c.moveToFirst(); !c.isAfterLast(); c.moveToNext()){
					EventPojo event=new EventPojo();
					int iRowId=c.getColumnIndex(KEY_ROW_ID);
					int iEventName=c.getColumnIndex(KEY_EVENT_NAME);
					int iClientName=c.getColumnIndex(KEY_CLIENT_NAME);
					int iMobileNo=c.getColumnIndex(KEY_MOBILE_NO);
					int iEmail=c.getColumnIndex(KEY_EMAIL);
					int iAddress=c.getColumnIndex(KEY_ADDRESS);
					int iStartDate=c.getColumnIndex(KEY_STARTDATE);
					int iEndDate=c.getColumnIndex(KEY_ENDDATE);
					int iDay=c.getColumnIndex(KEY_DAY);
					int iMonth=c.getColumnIndex(KEY_MONTH);
					int iYear=c.getColumnIndex(KEY_YEAR);
					
					int rowId=c.getInt(iRowId);
					String eventname=c.getString(iEventName);
					String clientname=c.getString(iClientName);
					String mobileno=c.getString(iMobileNo);
					String email=c.getString(iEmail);
					String address=c.getString(iAddress);
					String startdate=c.getString(iStartDate);
					String enddate=c.getString(iEndDate);
					String day=c.getString(iDay);
					String month1=c.getString(iMonth);
					String year1=c.getString(iYear);
					
					event.setRow_Id(rowId);
					event.setEventname(eventname);
					event.setClientname(clientname);
					event.setMobileno(mobileno);
					event.setEmail(email);
					event.setAddress(address);
					event.setStartdate(startdate);
					event.setEnddate(enddate);
					event.setDay(day);
					event.setMonth(month1);
					event.setYear(year1);
					
					eventdata.add(event);
					
				}
				
				
				return eventdata;
			}
			
			//Delete data
			public long delete(int id){
				return ourDatabase.delete(DATABASE_TABLE, KEY_ROW_ID+"="+id, null);
			}
			
			
			
}
