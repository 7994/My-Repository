package com.example.appeventcal;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;




public class EventDetail extends Activity {
	
	private TextView txtename;
	private TextView txtcname;
	private TextView txtmobileno;
	private TextView txtemail;
	private TextView txtaddress;
	private TextView txtsdate;
	private TextView txtedate;
	private TextView txtregdate;
	private Button btndelete;

	private int rowid;
	private ImageButton btnback;
	private String d;
	private String m;
	private String y;
	
	
	
	@Override
	public boolean onKeyUp(int keyCode, KeyEvent event) {
		// TODO Auto-generated method stub
		if(keyCode==KeyEvent.KEYCODE_BACK){
			Intent ww=new Intent();
			ww.putExtra("day", d);
			ww.putExtra("month", m);
			ww.putExtra("year", y);
			setResult(2, ww);
			finish();
			return true;
		}
		return super.onKeyUp(keyCode, event);
	}
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.eventdetail);
		
		//get intent
		Intent i=getIntent();
		Bundle extra=i.getExtras();
		
		String ename=extra.getString("ename");
		String cname=extra.getString("cname");
		String mobileno=extra.getString("mobileno");
		String email=extra.getString("email");
		String address=extra.getString("address");
		String sdate=extra.getString("sdate");
		String edate=extra.getString("edate");
		String regdate=extra.getString("regdate");
		rowid=extra.getInt("rowid");
		
		d=extra.getString("day");
		m=extra.getString("month");
		y=extra.getString("year");
		
		//TextView Ids 
		txtename=(TextView)findViewById(R.id.txteventname);
		txtcname=(TextView)findViewById(R.id.txtclientname);
		txtmobileno=(TextView)findViewById(R.id.txtmobileno);
		txtemail=(TextView)findViewById(R.id.txtemail);
		txtaddress=(TextView)findViewById(R.id.txtaddress);
		txtsdate=(TextView)findViewById(R.id.txtstartdate);
		txtedate=(TextView)findViewById(R.id.txtenddate);
		txtregdate=(TextView)findViewById(R.id.txtregdate);
		
		txtename.setPaintFlags(txtename.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
		txtename.setText(ename);
		txtcname.setPaintFlags(txtcname.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
		txtcname.setText(cname);
		txtmobileno.setPaintFlags(txtmobileno.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
		txtmobileno.setText(mobileno);
		txtemail.setPaintFlags(txtemail.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
		txtemail.setText(email);
		txtaddress.setPaintFlags(txtaddress.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
		txtaddress.setText(address);
		txtsdate.setPaintFlags(txtsdate.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
		txtsdate.setText(sdate);
		txtedate.setPaintFlags(txtedate.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
		txtedate.setText(edate);
		txtregdate.setPaintFlags(txtregdate.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
		txtregdate.setText(regdate);
		
		//back button
		btnback=(ImageButton)findViewById(R.id.btnimageback);
		btnback.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent vv=new Intent();
				vv.putExtra("day", d);
				vv.putExtra("month", m);
				vv.putExtra("year", y);
				setResult(2, vv);
				finish();
			}
		});
		//button delete
		btndelete=(Button)findViewById(R.id.btnDelete);
		btndelete.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				EventDB db=new EventDB(EventDetail.this);
				db.open();
				long id=db.delete(rowid);
				db.close();
				if(id==0){
					Toast.makeText(EventDetail.this, "Not Deleted", Toast.LENGTH_SHORT).show();
					
				}
				else{
					Toast.makeText(EventDetail.this, "Deleted", Toast.LENGTH_SHORT).show();
					Intent x=new Intent();
					
					
					x.putExtra("day", d);
					x.putExtra("month", m);
					x.putExtra("year", y);
				
					
					setResult(2, x);
					finish();
						}
				
			}
		});
		
		
	}
	

}
