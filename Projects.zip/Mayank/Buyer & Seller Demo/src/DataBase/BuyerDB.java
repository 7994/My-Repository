package DataBase;



import Pojo.Buyer;
import Pojo.Seller;
import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class BuyerDB {
	
	
	//Database table Details.......
	
	public static final String KEY_BUYERNAME="Buyername";
	public static final String KEY_EMAIL="Email";
	public static final String KEY_PHONENUMBER="Phonenumber";
	private static final String DATABASE_TABLE="BuyerDB";
	private static final String DATABASE_NAME="BuyerDetailDB";
	
	private static final int DATABASE_VERSION=6;
	
	//Constructor of class BuyerDB..

		public BuyerDB(Context context){
			this.ourContext=context;
			System.out.println("Constructor called and context is --"+ourContext);
		}
		//Useful objects.................

		private final Context ourContext;
		private DBHelper ourHelper;
		private SQLiteDatabase ourDatabase;
		
		
		//DBHelper class starts..........
		
		private class DBHelper extends SQLiteOpenHelper{

			public DBHelper(Context context) {
				super(context, DATABASE_NAME, null, DATABASE_VERSION);
				// TODO Auto-generated constructor stub
			}

			@Override
			public void onCreate(SQLiteDatabase db) {
				// TODO Auto-generated method stub
				System.out.println("Going to Create Database");
				String query="CREATE TABLE IF NOT EXISTS "+DATABASE_TABLE+
							      					 " ("+KEY_EMAIL+" TEXT PRIMARY KEY, "
							      					 	 +KEY_BUYERNAME+" TEXT NOT NULL, "
							      					 	 +KEY_PHONENUMBER+" TEXT NOT NULL);";
				
				
				Log.d("SQL Query", query);
				System.out.println("Database query is ---");
				db.execSQL(query);
			}

			@Override
			public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
				// TODO Auto-generated method stub
				db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE);
				onCreate(db);
			}
			
		}
		
		
		//DBHelper class Ends............
		
		
		//Database Operations............
		
		//Open DBHelper
		public BuyerDB open(){
			ourHelper=new DBHelper(ourContext);
			System.out.println("ourHelper Created-------");
			ourDatabase=ourHelper.getWritableDatabase();
			System.out.println("ourDatabase Created-------");
			return this;
		}
		//Close DBHelper
		public void close(){
			ourHelper.close();
		}
		
		//Insert one raw -shopname,email,phonenumber
		public long insertintoBuyerDB(Buyer b){
			
			ContentValues values=new ContentValues();
			
			
			values.put(KEY_EMAIL, b.getEmail());
			values.put(KEY_BUYERNAME, b.getBuyername());
			values.put(KEY_PHONENUMBER, b.getPhonenumber());
			
			return ourDatabase.insert(DATABASE_TABLE, null, values);
		}

}
