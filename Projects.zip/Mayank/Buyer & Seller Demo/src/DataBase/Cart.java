package DataBase;

import java.util.ArrayList;

import Pojo.MyCart;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class Cart {
	
	private final static String KEY_EMAIL="Email";
	private final static String KEY_PNAME="ProductName";
	private final static String KEY_PQUANTITY="ProductQuantity";
	private final static String KEY_PPRICE="ProductPrice";
	
	private final static String DATABASE_NAME="CartDetail";
	private final static String DATABASE_TABLE="CartDB";
	
	private static final int DATABASE_VERSION=6;
	
	private static final String[] columns={KEY_PNAME,KEY_PQUANTITY,KEY_PPRICE};
	
	//Constructor of class cart
	public Cart(Context context){
		this.ourContext=context;
	}
	
	//Usefull object
	Context ourContext;
	DBHelper ourHelper;
	SQLiteDatabase ourDatabase;
	private String[] whereArgs;
	
	
	//Helper class starts
	
	private class DBHelper extends SQLiteOpenHelper{

		public DBHelper(Context context) {
			super(context,DATABASE_NAME, null, DATABASE_VERSION);
			// TODO Auto-generated constructor stub
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			// TODO Auto-generated method stub
			String query="CREATE TABLE IF NOT EXISTS "+DATABASE_TABLE+
							"("+KEY_EMAIL +" TEXT NOT NULL, "+
								KEY_PNAME+" TEXT PRIMARY KEY, "+
								KEY_PQUANTITY+" TEXT NOT NULL, "+
								KEY_PPRICE+" TEXT NOT NULL );";
			Log.d("SQL Query", query);
			db.execSQL(query);
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			// TODO Auto-generated method stub
			db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE);
			onCreate(db);
		}
		
	}
	//Helper class ends
	
	//Database operations
	
	//open DBHelper
	public Cart open(){
		ourHelper=new DBHelper(ourContext);
		ourDatabase=ourHelper.getWritableDatabase();
		return this;
	}
	
	//Close DBHelper
		public void close(){
			ourHelper.close();
		}
		
		
		//insert into database
		
		public long insertintoCart(String email,String pname,String pquantity,String pprice){
			
			ContentValues values=new ContentValues();
			values.put(KEY_EMAIL, email);
			values.put(KEY_PNAME, pname);
			values.put(KEY_PQUANTITY, pquantity);
			values.put(KEY_PPRICE, pprice);
			
			return ourDatabase.insert(DATABASE_TABLE, null, values);
		}
	
		//Search all Product from email id
		
		public ArrayList<MyCart> mycart(String email){
			ArrayList<MyCart> mycart=new ArrayList<MyCart>();
			
			Cursor c=ourDatabase.query(DATABASE_TABLE, columns, KEY_EMAIL+"="+"'"+email+"'", null, null, null, null);
			for(c.moveToFirst();!c.isAfterLast();c.moveToNext()){
				MyCart m=new MyCart();
				int ipname=c.getColumnIndex(KEY_PNAME);
				int ipquantity=c.getColumnIndex(KEY_PQUANTITY);
				int ipprice=c.getColumnIndex(KEY_PPRICE);
				
				
				m.setPname(c.getString(ipname));
				m.setPquantity(c.getString(ipquantity));
				m.setPprice(c.getString(ipprice));
				mycart.add(m);
				
				
			}
			
			
			return mycart;
			
		}
		
		// delete one entry
		
		public int delete(String email,String pname) {
			
			return ourDatabase.delete(DATABASE_TABLE, KEY_EMAIL+"="+"'"+email+"'"+" AND "+KEY_PNAME+"="+"'"+pname+"'", null);
		}
	
	
	
	
	

}
