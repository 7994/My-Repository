package DataBase;


import java.util.ArrayList;

import Pojo.Buyer;
import Pojo.LoginCheck;
import Pojo.Seller;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class LoginDB {
	
	//Database table details........
	private static final String KEY_ROW_ID = "_id";
	private static final String KEY_EMAIL="Email";
	private static final String KEY_PASSWORD="Password";
	private static final String KEY_LOGER="Loger";
	
	private static final String DATABASE_TABLE="LoginDB";
	private static final String DATABASE_NAME="SellerLoginDB";
	
	private static final int DATABASE_VERSION=6;
	
	private static final String[] columns={KEY_EMAIL,KEY_PASSWORD,KEY_LOGER};
	
	
	//Constructor of class LoginDB..
	public LoginDB(Context context){
		this.ourContext=context;
		System.out.println("Constructor called and context is --"+ourContext);
	}
	
	//Useful objects.................
	private final Context ourContext;
	private DBHelperlogin ourHelper;
	private SQLiteDatabase ourDatabase;
	
	
	//DBHelper class starts..........
	private class DBHelperlogin extends SQLiteOpenHelper{

		public DBHelperlogin(Context context) {
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
			// TODO Auto-generated constructor stub
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			// TODO Auto-generated method stub
			System.out.println("Going to Create Database");
			String query = "CREATE TABLE IF NOT EXISTS " +DATABASE_TABLE + 
					" (" +KEY_ROW_ID+" INTEGER PRIMARY KEY AUTOINCREMENT, " 
					+ KEY_EMAIL +" TEXT NOT NULL, " 
					+ KEY_PASSWORD +" TEXT NOT NULL, "					 
					+ KEY_LOGER +" TEXT NOT NULL);" ;
			
			Log.d("SQL Query", query);
			
			db.execSQL(query);
			
			
			
			
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			// TODO Auto-generated method stub
			db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE);
			onCreate(db);
		}
		
	}
	
	//DBHelper class Ends............
	
	
	//Database Operations............
		
	//Open DBHelper
	
	public LoginDB open(){
		ourHelper=new DBHelperlogin(ourContext);
		System.out.println("ourHelper Created-------");
		ourDatabase=ourHelper.getWritableDatabase();
		System.out.println("ourDatabase Created-------");
		return this;
		
	}
	//Close DBHelper
	public void close(){
		ourHelper.close();
	}
	
	
	//Insert one raw -email,password,loger
	public long insertintoLoginDB(Seller s){
		
		ContentValues values=new ContentValues();
		
		values.put(KEY_EMAIL, s.getEmail());
		values.put(KEY_PASSWORD, s.getPassword());
		values.put(KEY_LOGER, s.getLoger());
		
		return ourDatabase.insert(DATABASE_TABLE, null, values);
		
	}
public long insertintoLoginDBforBuyer(Buyer b){
		
		ContentValues values=new ContentValues();
		
		values.put(KEY_EMAIL, b.getEmail());
		values.put(KEY_PASSWORD, b.getPassword());
		values.put(KEY_LOGER, b.getLoger());
		
		return ourDatabase.insert(DATABASE_TABLE, null, values);
		
	}
public ArrayList<LoginCheck> loginData(){
	
	ArrayList<LoginCheck> logindata=new ArrayList<LoginCheck>();
	
	Cursor c=ourDatabase.query(DATABASE_TABLE, columns, null, null, null, null, null);
	
	for(c.moveToFirst(); !c.isAfterLast(); c.moveToNext()){
		LoginCheck l=new LoginCheck();
		int iEmail=c.getColumnIndex(KEY_EMAIL);
		int ipassword=c.getColumnIndex(KEY_PASSWORD);
		int iloger=c.getColumnIndex(KEY_LOGER);
		
		String email=c.getString(iEmail);
		String password=c.getString(ipassword);
		String loger=c.getString(iloger);
		
		l.setEmail(email);
		l.setPassword(password);
		l.setLoger(loger);
		
		logindata.add(l);
	}
	return logindata; 
}

}
