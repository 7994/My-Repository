package DataBase;



import java.util.ArrayList;

import Pojo.Product;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.view.ViewDebug.IntToString;

public class ProductDB {
	
	//Database Table details
	
	public static final String KEY_PRODUCTNAME="ProductName";
	public static final String KEY_PRODUCTQUANTITY="ProductQuantity";
	public static final String KEY_PRODUCTPRICE="ProductPrice";
	
	private static final String DATABASE_TABLE="ProductDB";
	private static final String DATABASE_NAME="ProductDetailDB";
	
	private static final int DATABASE_VERSION=6;
	
	private static final String[] columns={KEY_PRODUCTNAME,KEY_PRODUCTQUANTITY,KEY_PRODUCTPRICE};
	private static final String[] column={KEY_PRODUCTQUANTITY};
	
	public ProductDB(Context context){
		this.ourContext=context;
	}
	//Useful objects.................

	private final Context ourContext;
	private DBHelper ourHelper;
	private SQLiteDatabase ourDatabase;
	
	
	
	//DBHelper class starts..........
	
			private class DBHelper extends SQLiteOpenHelper{

				public DBHelper(Context context) {
					super(context, DATABASE_NAME, null, DATABASE_VERSION);
					// TODO Auto-generated constructor stub
				}

				@Override
				public void onCreate(SQLiteDatabase db) {
					// TODO Auto-generated method stub
					System.out.println("Going to Create Database");
					String query="CREATE TABLE IF NOT EXISTS "+DATABASE_TABLE+
								      					 " ("+KEY_PRODUCTNAME+" TEXT PRIMARY KEY, "
								      					 	 +KEY_PRODUCTQUANTITY+" TEXT NOT NULL, "
								      					 	 +KEY_PRODUCTPRICE+" TEXT NOT NULL);";
					
					
					Log.d("SQL Query", query);
					System.out.println("Database query is ---");
					db.execSQL(query);
				}

				@Override
				public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
					// TODO Auto-generated method stub
					db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE);
					onCreate(db);
				}
				
			}
			
			
			//DBHelper class Ends............
			
			
			//Open DBHelper
			public ProductDB open(){
				ourHelper=new DBHelper(ourContext);
				System.out.println("ourHelper Created-------");
				ourDatabase=ourHelper.getWritableDatabase();
				System.out.println("ourDatabase Created-------");
				return this;
			}
			//Close DBHelper
			public void close(){
				ourHelper.close();
			}
			
			//Inserting Product details
			public long insertProduct(Product p){
				ContentValues values=new ContentValues();
				values.put(KEY_PRODUCTNAME, p.getPname());
				values.put(KEY_PRODUCTQUANTITY, p.getPquantity());
				values.put(KEY_PRODUCTPRICE, p.getPprice());
				
				
				
				return ourDatabase.insert(DATABASE_TABLE, null, values);
			}
			
			//Searching for all products
			public ArrayList<Product> getallproductdata(){
				ArrayList<Product> product=new ArrayList<Product>();
				
				Cursor c=ourDatabase.query(DATABASE_TABLE, columns, null, null, null, null, null);
				for(c.moveToFirst(); !c.isAfterLast(); c.moveToNext()){
					Product p=new Product();
					int iPname=c.getColumnIndex(KEY_PRODUCTNAME);
					int iPquantity=c.getColumnIndex(KEY_PRODUCTQUANTITY);
					int iPprice=c.getColumnIndex(KEY_PRODUCTPRICE);
					
					String pname=c.getString(iPname);
					String pquantity=c.getString(iPquantity);
					String pprice=c.getString(iPprice);
					
					p.setPname(pname);
					p.setPquantity(pquantity);
					p.setPprice(pprice);
					
					product.add(p);
					
				}
				
				
				return product;
			}
			
			//read all product details from product name
			public Product getproductdetail(String value){
				String v=value;
				Product p=new Product();
				Cursor c=ourDatabase.query(DATABASE_TABLE, columns, KEY_PRODUCTNAME+"="+"'"+v+"'", null, null, null, null);
				
				if(c.moveToFirst()){
					int ipname=c.getColumnIndex(KEY_PRODUCTNAME);
					int ipquantity=c.getColumnIndex(KEY_PRODUCTQUANTITY);
					int ipprice=c.getColumnIndex(KEY_PRODUCTPRICE);
					
					String pname=c.getString(ipname);
					String pquantity=c.getString(ipquantity);
					String pprice=c.getString(ipprice);
					p.setPname(pname);
					p.setPquantity(pquantity);
					p.setPprice(pprice);
					
					
				}
				return p;
			}
			
			public int selectAndUpdateProductDB(String pname){
				
				Cursor c=ourDatabase.query(DATABASE_TABLE, column, KEY_PRODUCTNAME+"="+"'"+pname+"'", null, null, null, null);
				String q="";
				if(c.moveToNext()){
					 q=c.getString(c.getColumnIndex(KEY_PRODUCTQUANTITY));
				}
				int qty=Integer.parseInt(q);
				int finalqty=qty-1;
				
				String quantity=finalqty+"";
				
				ContentValues values = new ContentValues();
				
				values.put(KEY_PRODUCTQUANTITY, quantity);
				
				return ourDatabase.update(DATABASE_TABLE, values, KEY_PRODUCTNAME+"="+"'"+pname+"'", null);
			}
			
			
			public int delete(String pname) {
				
				return ourDatabase.delete(DATABASE_TABLE,KEY_PRODUCTNAME+"="+"'"+pname+"'", null);
			}
			
	

}
