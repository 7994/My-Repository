package DataBase;



import Pojo.Seller;
import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class SellerDataBase {
//Database table details........
	
	private static final String KEY_SHOPNAME="Shopname";
	private static final String KEY_EMAIL="Email";
	private static final String KEY_PHONENUMBER="Phonenumber";
	private static final String DATABASE_TABLES="MySellerDB";
	
	private static final String KEY_PASSWORD="Password";
	private static final String KEY_LOGER="Loger";
	private static final String DATABASE_TABLEL="MyLoginDB";
	private static final String DATABASE_NAME="BuyerSellerDB";
	
	private static final int DATABASE_VERSION=1;
	
	
	public SellerDataBase(Context context) {
		// TODO Auto-generated constructor stub
		this.ourContext=context;
		System.out.println("Constructor called and context is --"+ourContext);
	}
	
	
	//Useful objects.................

		private final Context ourContext;
		private DBHelperseller ourHelperseller;
		private DBHelperlogin ourHelperlogin;
		private SQLiteDatabase ourDatabaseseller;
		private SQLiteDatabase ourDatabaselogin;
		
		
		//DBHelper class starts..........
		
		private class DBHelperseller extends SQLiteOpenHelper{

			public DBHelperseller(Context context) {
				super(context, DATABASE_NAME, null, DATABASE_VERSION);
				// TODO Auto-generated constructor stub
			}

			@Override
			public void onCreate(SQLiteDatabase db) {
				// TODO Auto-generated method stub
				System.out.println("Going to Create Database for seller");
				String query="CREATE TABLE IF NOT EXISTS "+DATABASE_TABLES+
							      					 " ("+KEY_SHOPNAME+" TEXT PRIMARY KEY, "
							      					 	 +KEY_EMAIL+" TEXT NOT NULL, "
							      					 	 +KEY_PHONENUMBER+" TEXT NOT NULL);";
				
				
				Log.d("SQL Query for seller", query);
				System.out.println("Database for seller query is ---");
				db.execSQL(query);
			}

			@Override
			public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
				// TODO Auto-generated method stub
				db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLES);
				onCreate(db);
			}
			
		}
		
		
		//DBHelper class Ends............
		
		
		private class DBHelperlogin extends SQLiteOpenHelper{

			public DBHelperlogin(Context context) {
				super(context, DATABASE_NAME, null, DATABASE_VERSION);
				// TODO Auto-generated constructor stub
			}

			@Override
			public void onCreate(SQLiteDatabase db) {
				// TODO Auto-generated method stub
				System.out.println("Going to Create Database for Login");
				String query="CREATE TABLE IF NOT EXISTS "+DATABASE_TABLEL+
							      					 " ("+KEY_EMAIL+" TEXT NOT NULL, "
							      					 	 +KEY_PASSWORD+" TEXT NOT NULL, "
							      					 	 +KEY_LOGER+" TEXT NOT NULL);";
				
				
				Log.d("SQL Query For login", query);
				System.out.println("Database query for Login is ---");
				db.execSQL(query);
			}

			@Override
			public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
				// TODO Auto-generated method stub
				db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLEL);
				onCreate(db);
			}
			
		}
		
		
		//DBHelper class Ends............
		
		
		
		
		
		
		//Open DBHelper
		public SellerDataBase openseller(){
			ourHelperseller=new DBHelperseller(ourContext);
			System.out.println("ourHelperseller Created-------");
			ourDatabaseseller=ourHelperseller.getWritableDatabase();
			System.out.println("ourDatabaseseller Created-------");
			return this;
		}
		//Close DBHelper
		public void closeseller(){
			ourHelperseller.close();
		}	
		
		
		
		//Open DBHelper
				public SellerDataBase openlogin(){
					ourHelperlogin=new DBHelperlogin(ourContext);
					System.out.println("ourHelperlogin Created-------");
					ourDatabaselogin=ourHelperlogin.getWritableDatabase();
					System.out.println("ourDatabaselogin Created-------");
					return this;
				}
				//Close DBHelper
				public void closelogin(){
					ourHelperlogin.close();
				}	
				//Insert one raw -shopname,email,phonenumber
				public long insertintoSellerDB(Seller s){
					
					ContentValues values=new ContentValues();
					
					values.put(KEY_SHOPNAME, s.getShopname());
					values.put(KEY_EMAIL, s.getEmail());
					values.put(KEY_PHONENUMBER, s.getPhonenumber());
					
					return ourDatabaseseller.insert(DATABASE_TABLES, null, values);
				}
				
				
				//Insert one raw -email,password,loger
				public long insertintoLoginDB(Seller s){
					
					ContentValues values=new ContentValues();
					
					values.put(KEY_EMAIL, s.getEmail());
					values.put(KEY_PASSWORD, s.getPassword());
					values.put(KEY_LOGER, s.getLoger());
					
					return ourDatabaselogin.insert(DATABASE_TABLEL, null, values);
					
				}

}
