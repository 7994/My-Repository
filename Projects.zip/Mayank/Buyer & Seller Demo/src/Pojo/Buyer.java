package Pojo;

public class Buyer {
	
	private String buyername;
	private String email;
	private String phonenumber;
	private String password;
	private String loger;
	public String getBuyername() {
		return buyername;
	}
	public void setBuyername(String buyername) {
		this.buyername = buyername;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhonenumber() {
		return phonenumber;
	}
	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getLoger() {
		return loger;
	}
	public void setLoger(String loger) {
		this.loger = loger;
	}
	
	

}
