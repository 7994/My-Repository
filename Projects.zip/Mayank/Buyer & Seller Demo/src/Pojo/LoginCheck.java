package Pojo;

public class LoginCheck {

	
	private String email;
	private String password;
	private String loger;
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getLoger() {
		return loger;
	}
	public void setLoger(String loger) {
		this.loger = loger;
	}
	
}
