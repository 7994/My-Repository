package Pojo;

public class Seller {
	
	
	private String shopname;
	private String email;
	private String phonenumber;
	private String password;
	private String loger;
	
	//setter method of shopname
	public void setShopname(String name){
		this.shopname=name;
	}
	//getter method of shopname
	public String getShopname(){
		return shopname;
	}
	//setter method of email
	public void setEmail(String email){
		this.email=email;
	}
	//getter method of email
	public String getEmail(){
		return email;
	}
	//setter method of phonenumber
	public void setPhonenumber(String phonenumber){
		this.phonenumber=phonenumber;
	}
	//Gettwr method of phonenumber
	public String getPhonenumber(){
		return phonenumber;
	}
	//Setter method of password
	public void setPassword(String password){
		this.password=password;
	}
	public String getPassword(){
		return password;
	}
	//Setter method of loger
	public void setLoger(String loger){
		this.loger=loger;
	}
	//Getter method of loger
	public String getLoger(){
		return loger;
	}

}
