package com.example.buyersellerdemo;

import java.util.ArrayList;



import DataBase.ProductDB;
import Pojo.Product;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

public class BuyerhomeActivity extends Activity implements OnClickListener{
	

	private Button btnlogout;
	private Button btnback;
	
	
	private SharedPreferences prefs;
	private ListView list;
	private ArrayAdapter<String> aa;
	private Button btnmycart;
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		getActionBar().hide();
		setContentView(R.layout.activity_buyerhome);
		btnlogout=(Button)findViewById(R.id.btnhomesignout);
		btnlogout.setText("Logout");
		btnback=(Button)findViewById(R.id.btnback);
		btnmycart=(Button)findViewById(R.id.btnmycart);
		btnlogout.setOnClickListener(this);
		btnback.setOnClickListener(this);
		btnmycart.setOnClickListener(this);
		
		
		
		
		
		list=(ListView)findViewById(R.id.listofproduct);
		
		ProductDB db=new ProductDB(BuyerhomeActivity.this);
		ArrayList<Product> data=new ArrayList<Product>();
		db.open();
		data=db.getallproductdata();
		db.close();
		final ArrayList<String> productname=new ArrayList<String>();
		
		for(Product p:data){
			if(Integer.parseInt(p.getPquantity())>0){
				productname.add(p.getPname());
			}else{
				ProductDB d=new ProductDB(BuyerhomeActivity.this);
				d.open();
				d.delete(p.getPname());
				d.close();
			}
		}
		
		
			aa=new ArrayAdapter<String>(BuyerhomeActivity.this, android.R.layout.simple_list_item_1, productname);
	        
	        list.setAdapter(aa);
	        aa.notifyDataSetChanged();
	        
	        
	        //ListView clicked
	        list.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> arg0, View arg1,
						int arg2, long arg3) {
					// TODO Auto-generated method stub
					String value=productname.get(arg2);
					Intent i=new Intent(BuyerhomeActivity.this,ProductdetailActivity.class);
					i.putExtra("ProductName", value);
					startActivity(i);
					//finish();
					
					
					
				}
			});
	        
	        
		
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
		switch (v.getId()) {
		case R.id.btnback:
			finish();
			
			break;
		
		case R.id.btnhomesignout:
			//set loggedin value as false
			prefs=getSharedPreferences("myprefs",MODE_APPEND);
			Editor edit=prefs.edit();
			edit.putBoolean("buyerlogedin", false);
			edit.putString("email", "");
			edit.commit();
			
			
			Intent logout=new Intent(BuyerhomeActivity.this, MainActivity.class);
			startActivity(logout);
			finishAffinity();
			break;
			
		case R.id.btnmycart:
			
			Intent i=new Intent(BuyerhomeActivity.this, MycartActivity.class);
			startActivity(i);
			
			break;

		default:
			break;
		}
		
		
	}

}
