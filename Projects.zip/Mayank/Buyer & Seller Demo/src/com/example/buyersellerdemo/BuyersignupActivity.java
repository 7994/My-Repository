package com.example.buyersellerdemo;

import DataBase.BuyerDB;
import DataBase.LoginDB;
import DataBase.SellerDB;
import Pojo.Buyer;
import Pojo.Seller;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class BuyersignupActivity extends Activity implements OnClickListener {
	private Button btngotologin;
	private Button btnback;
	private Button btnsubmit;
	private SharedPreferences prefs;
	private TextView editbuyername;
	private TextView editemail;
	private TextView editphonenumber;
	private TextView editpassword;
	private TextView title;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		getActionBar().hide();
		setContentView(R.layout.activity_buyersignup);
		
		//Button ids
		btngotologin=(Button)findViewById(R.id.btnhomesignout);
		btngotologin.setText("Login");
		btnback=(Button)findViewById(R.id.btnback);
		btnsubmit=(Button)findViewById(R.id.btnsubmitbuyer);
		
		//TextView Ids
		editbuyername=(TextView)findViewById(R.id.editbuyername);
		editemail=(TextView)findViewById(R.id.editemail);
		editphonenumber=(TextView)findViewById(R.id.editphonenumber);
		editpassword=(TextView)findViewById(R.id.editpassword);
		
		//TextView id
		title=(TextView)findViewById(R.id.txttitle);
		//Initialize Shared Preference
		prefs=getSharedPreferences("myprefs", MODE_APPEND);
		String text=prefs.getString("loger", null);
		
		//Set Title
		title.setText(text);
		
		
		//Button Click
		btngotologin.setOnClickListener(this);
		btnback.setOnClickListener(this);
		btnsubmit.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
		switch (v.getId()) {
		case R.id.btnback:
			
			
			finish();
			
			break;
		case R.id.btnhomesignout:
			
			Intent j=new Intent(BuyersignupActivity.this, MainActivity.class);
			startActivity(j);
			finishAffinity();
			
			break;
		case R.id.btnsubmitbuyer:
			 
			submit();
			
			break;

		default:
			
			break;
		}
		
	}
		
		
		
		//Button submit method 
		private void submit(){
			prefs=getSharedPreferences("myprefs", MODE_APPEND);
			String loger=prefs.getString("loger", null);
			
			String name,email,phonenumber,password;
			boolean flagname=false,flagemail=false,flagphonenumber=false,flagpassword=false;
			
			name=editbuyername.getText().toString().trim();
			email=editemail.getText().toString().trim();
			phonenumber=editphonenumber.getText().toString().trim();
			password=editpassword.getText().toString().trim();
			
			
			Buyer buyer=new Buyer();
			buyer.setBuyername(name);
			buyer.setEmail(email);
			buyer.setPhonenumber(phonenumber);
			buyer.setPassword(password);			
			buyer.setLoger(loger);
			//Validation check for Shopname
			if(!name.matches("^[a-zA-Z//s]{3,}$"))
			{
				editbuyername.setError("Enter aphabet only.");
				
			}		
			else
			{			
				flagname=true;
			}
			
			//Validation check for Email
			if(!email.matches("^[A-Za-z][A-Za-z0-9]*([._-]?[A-Za-z0-9]+)@[A-Za-z].[A-Za-z]{0,13}?.[A-Za-z]{0,3}$"))
			{
				editemail.setError("Enter valid Email id.");
				
			}
			else
			{			
				flagemail=true;
			}
			
			//Validation check for Phonenumber
			if(!phonenumber.matches("^[0-9]*$")){
				editphonenumber.setError("Enter valid number");
			}
			else
			{
				flagphonenumber=true;
			}
			
			//Validation check for Password
			if(!password.matches("^.{4,10}$")){
				editpassword.setError("Enter Valid password");
			}
			else
			{
				flagpassword=true;
			}
			if(flagname&&flagemail&&flagphonenumber&&flagpassword){
				
				
				
				
				//Create object of class SellerDB
			      
			      BuyerDB dbbuyer=new BuyerDB(BuyersignupActivity.this);
			//Open dbseller
			      dbbuyer.open();
			
			//insert shopename,emai,phonenumber into SellerDB
			
			long id=dbbuyer.insertintoBuyerDB(buyer);			
			//close dbseller
			dbbuyer.close();
			
			if(id==-1){
				Toast.makeText(BuyersignupActivity.this, "Id already registered.", Toast.LENGTH_SHORT).show();
				
			}
			else
			{
				//Create object of class LoginDB
				LoginDB dblogin=new LoginDB(BuyersignupActivity.this);
				//Open dbLogin
				dblogin.open();
				
				//insrt email,password,loger into LoginDB
				long id1=dblogin.insertintoLoginDBforBuyer(buyer);
				//Close dblogin
				dblogin.close();
				
				if(id1==-1){
					Toast.makeText(BuyersignupActivity.this, "Error while inserting.", Toast.LENGTH_SHORT).show();
				}
				else
				{
					Toast.makeText(BuyersignupActivity.this, "Signup Successfull. ", Toast.LENGTH_LONG).show();
					
					prefs=getSharedPreferences("myprefs", MODE_APPEND);
					
					//Create Editor for editing prefs
					Editor editbuyer=prefs.edit();
					
					//Add Buyer in prefs
					
					editbuyer.putString("email", email);
					editbuyer.commit();
					
					
					
					Intent i=new Intent(BuyersignupActivity.this, BuyerhomeActivity.class);
					startActivity(i);
					finish();
				}
				
			}

				
				
				

				
				
				
			}
			
		
	}

}
