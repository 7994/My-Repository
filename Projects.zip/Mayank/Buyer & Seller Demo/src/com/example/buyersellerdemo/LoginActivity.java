package com.example.buyersellerdemo;



import java.util.ArrayList;
import DataBase.LoginDB;
import Pojo.LoginCheck;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;

import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends Activity implements OnClickListener{
	private SharedPreferences prefs;
	

	private TextView title;
	private Button btnback;
	private Button btnlogin;
	private Button btnsignup;
	private EditText checkid;
	private EditText checkpassword;
	private CheckBox rememberme;
	private String text;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		getActionBar().hide();
		setContentView(R.layout.activity_login);
		
		//Button Ids
		btnback=(Button)findViewById(R.id.btnback);
		btnlogin=(Button)findViewById(R.id.btnlogin);
		btnsignup=(Button)findViewById(R.id.btnsignup);
		
		//TextView id
		title=(TextView)findViewById(R.id.txttitle);
		checkid=(EditText)findViewById(R.id.editid);
		checkpassword=(EditText)findViewById(R.id.editpassword);
		
		//Chechbox id
		rememberme=(CheckBox)findViewById(R.id.checkremember);
		
		//Initialize Shared Preference
		prefs=getSharedPreferences("myprefs", MODE_APPEND);
		text=prefs.getString("loger", null);
		
		//Set Title
		title.setText(text);
		
		//Button click
		btnback.setOnClickListener(this);
		btnlogin.setOnClickListener(this);
		btnsignup.setOnClickListener(this);
		
	}
	


	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
		switch (v.getId()) {
		case R.id.btnback:
			
			
			finish();
			
			break;
		case R.id.btnlogin:
			
			//call method login check
			logincheck();
			
			
			
			break;
		case R.id.btnsignup:
			
			
			prefs=getSharedPreferences("myprefs", MODE_APPEND);
			String loger=prefs.getString("loger", null);
			Intent j;
			
			
			if(loger.equals("Seller"))
			{
				Intent m=new Intent(LoginActivity.this, SellersignupActivity.class);
				startActivity(m);
				
			}
			else if(loger.equals("Buyer")){
				Intent n=new Intent(LoginActivity.this,BuyersignupActivity.class);
				startActivity(n);
				
				
			}
			else if(loger.equals(null))
			{
				Toast.makeText(LoginActivity.this, "Prefs value Null", Toast.LENGTH_SHORT).show();
			}
			else
			{
				Toast.makeText(LoginActivity.this, "Prefs not found", Toast.LENGTH_SHORT).show();
			}
			
			
			
			
		
		}
		
		
		
	}
	
	private void logincheck(){
		
		String idcheck=checkid.getText().toString().trim();
		String passwordcheck=checkpassword.getText().toString().trim();
		
		//Take who is loger from prefs
		prefs=getSharedPreferences("myprefs", MODE_APPEND);
		String loger=prefs.getString("loger", null);
		
		
		//Checking whether edittext is empty................................................... 
		if(idcheck.equals("")&&!passwordcheck.equals("")){
			Toast.makeText(LoginActivity.this,"Please insert Id.", Toast.LENGTH_SHORT).show();
			
		}
		else if(!idcheck.equals("")&&passwordcheck.equals("")){
			Toast.makeText(LoginActivity.this,"Please insert Password.", Toast.LENGTH_SHORT).show();
		}
		else if(idcheck.equals("")&&passwordcheck.equals("")){
			Toast.makeText(LoginActivity.this,"Please insert Id and Password.", Toast.LENGTH_SHORT).show();
		}
		else{
			
			//Nothing is empty So Perform operation starts.............................................
			ArrayList<LoginCheck> data=new ArrayList<LoginCheck>();
			
			LoginDB db=new LoginDB(LoginActivity.this);
			
			db.open();
			
			data=db.loginData();
			
//			int length=data.size();
			
//			Toast.makeText(LoginActivity.this, "Number of Elements:"+length, Toast.LENGTH_LONG).show();
			
			db.close();
			
			//Declaring Boolean................
			boolean gotobuyer=false;
			boolean gotoseller=false;
			boolean wrongplace=false;
			boolean passerror=false;
			boolean iderror=false;
			boolean idpasserror=false;
			String l="";
			
			
			//for loop starts...................
			for(LoginCheck p : data) {
				
				

			//Checking possible conditions to set Boolean value true Starts........
					if(idcheck.equals(p.getEmail())&&passwordcheck.equals(p.getPassword())){
					
						if(loger.equals(p.getLoger())){
							
							//.......................//
							if(loger.equals("Buyer")){
								gotobuyer=true;
								
								}
							else{
								gotoseller=true;
														
								}
							//.......................//
							
							}
						else {
						
							wrongplace=true;
							l=p.getLoger();
							

							}
				
					}
					else if(idcheck.equals(p.getEmail())&&!passwordcheck.equals(p.getPassword())){
						passerror=true;
					}
					else if(!idcheck.equals(p.getEmail())&&passwordcheck.equals(p.getPassword())){
						iderror=true;
					}				
					else if(!idcheck.equals(p.getEmail())&&!passwordcheck.equals(p.getPassword())){
						idpasserror=true;
					}
					else{
					}
		//Checking possible conditions to set Boolean values Ends..................
		
		
		}
		//for loop Ends............................................................
			
			
			
		//Action according to Boolean Values start.................................	
		if(gotobuyer){
			
			prefs=getSharedPreferences("myprefs", MODE_APPEND);
			
			//Create Editor for editing prefs
			Editor editbuyer1=prefs.edit();
			
			//Add Buyer in prefs
			
			editbuyer1.putString("email", idcheck);
			editbuyer1.commit();
			
			//remember me checking
			if(rememberme.isChecked()){
				//Initialize Shared Preference
				prefs=getSharedPreferences("myprefs", MODE_APPEND);
				
				//Create Editor for editing prefs
				Editor editbuyer=prefs.edit();
				
				//Add Buyer in prefs
				editbuyer.putBoolean("buyerlogedin", true);
				
				editbuyer.commit();
				finish();
			}
			Intent i=new Intent(LoginActivity.this, BuyerhomeActivity.class);
			startActivity(i);
			checkid.setText("");
			checkpassword.setText("");
		}
		else if(gotoseller){
			
			//remember me checking
			if(rememberme.isChecked()){
				//Initialize Shared Preference
				prefs=getSharedPreferences("myprefs", MODE_APPEND);
				
				//Create Editor for editing prefs
				Editor editseller=prefs.edit();
				
				//Add Buyer in prefs
				editseller.putBoolean("sellerlogedin", true);
				
				editseller.commit();
				finish();
			}
			Intent j=new Intent(LoginActivity.this, SellerhomeActivity.class);
			startActivity(j);
			checkid.setText("");
			checkpassword.setText("");
		}
		else if(wrongplace){
			Toast.makeText(LoginActivity.this, "You are "+l+".Please Login as "+l, Toast.LENGTH_SHORT).show();
			checkid.setText("");
			checkpassword.setText("");
		}
		else if(passerror){
			checkpassword.setError("Incorrect Password.");
		}
		else if(iderror){
			checkid.setError("Incorrect Id.");
		}
		else if(idpasserror){
			checkpassword.setError("Incorrect Password.");
			checkid.setError("Incorrect Id.");
		}
		else{
			
		}
		//Action according to Boolean Values Ends......................................	
			
			
		}
		//Nothing is empty So Perform operation Ends.............................................
		
		
		
	}

}
