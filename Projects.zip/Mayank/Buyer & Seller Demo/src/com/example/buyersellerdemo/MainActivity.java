package com.example.buyersellerdemo;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity extends Activity implements OnClickListener{
	private Button btnloginbuyer;
	private Button btnloginseller;
	private SharedPreferences prefs;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		getActionBar().hide();
		//Button Ids
		btnloginbuyer=(Button)findViewById(R.id.btnloginasbuyer);
		btnloginseller=(Button)findViewById(R.id.btnloginasseller);
		
		
		
		
		//Button click 
		btnloginbuyer.setOnClickListener(this);
		btnloginseller.setOnClickListener(this);
				
		
	}
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
		switch (v.getId()) {
		case R.id.btnloginasbuyer:
			//Check already logedin or not
			 prefs=getSharedPreferences("myprefs", MODE_APPEND);
		        boolean status=prefs.getBoolean("buyerlogedin", false);
		        if(status){
		        	Intent i=new Intent(MainActivity.this, BuyerhomeActivity.class);
					startActivity(i);
		        }
			
			
		        else{
			//Initialize Shared Preference
			prefs=getSharedPreferences("myprefs", MODE_APPEND);
			
			//Create Editor for editing prefs
			Editor editbuyer=prefs.edit();
			
			//Add Buyer in prefs
			editbuyer.putString("loger", "Buyer");
			editbuyer.commit();
			//Create Intent to go to next screen
			Intent i=new Intent(MainActivity.this, LoginActivity.class);
			startActivity(i);
		        }
						
			break;
			
		case R.id.btnloginasseller:
			
			//Check already logedin or not
			 prefs=getSharedPreferences("myprefs", MODE_APPEND);
		        boolean status1=prefs.getBoolean("sellerlogedin", false);
		        if(status1){
		        	Intent j=new Intent(MainActivity.this, SellerhomeActivity.class);
					startActivity(j);
		        }
		        else{
			
			//Initialize Shared Preference
			prefs=getSharedPreferences("myprefs", MODE_APPEND);
			
			//Create Editor for editing prefs
			Editor editseller=prefs.edit();
			
			//Add Buyer in prefs
			editseller.putString("loger", "Seller");
			editseller.commit();
			//Create Intent to go to next screen
			Intent j=new Intent(MainActivity.this, LoginActivity.class);
			startActivity(j);
		        }
			
			break;

		default:
			break;
		}
		
	}
	

}
