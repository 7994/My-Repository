package com.example.buyersellerdemo;

import java.util.ArrayList;

import DataBase.Cart;
import DataBase.ProductDB;
import Pojo.MyCart;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class MycartActivity extends Activity implements OnClickListener{
	
	private Button btnlogout;
	private Button btnback;
	private SharedPreferences prefs;
	private ListView list;
	private ArrayAdapter<String> aa;
	private TextView totalcount;
	ArrayList<String> check=new ArrayList<String>();
	private Button btnbuy;
	private EditText purchaseproduct;
	String purchase;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		getActionBar().hide();
		setContentView(R.layout.activity_mycart);
		
		//button ids
				btnlogout=(Button)findViewById(R.id.btnhomesignout);
				btnlogout.setText("Logout");
				btnback=(Button)findViewById(R.id.btnback);
				btnbuy=(Button)findViewById(R.id.btnbuy);
				
				
				btnlogout.setOnClickListener(this);
				btnback.setOnClickListener(this);
				btnbuy.setOnClickListener(this);
				
				totalcount=(TextView)findViewById(R.id.textView1);
				
				prefs=getSharedPreferences("myprefs", MODE_APPEND);
				String email=prefs.getString("email", "");
				
				list=(ListView)findViewById(R.id.listofproduct);
				
				purchaseproduct=(EditText)findViewById(R.id.editenterproduct);
				purchase=purchaseproduct.getText().toString().trim();
				
				
				Cart db=new Cart(MycartActivity.this);
				db.open();
				
				ArrayList<MyCart> data=new ArrayList<MyCart>();
				data=db.mycart(email);
				
				db.close();
				ArrayList<String> al=new ArrayList<String>();
				for(MyCart m:data){
					String name=m.getPname();
					al.add("Name "+name+" | Price "+m.getPprice()+"Rs. | Qty 1.");
					//add only prod name to check for checking user input
					check.add(name);
					
					}
				aa=new ArrayAdapter<String>(MycartActivity.this, android.R.layout.simple_list_item_1, al);
		        
		        list.setAdapter(aa);
		        aa.notifyDataSetChanged();
		        
		        totalcount.setText("MyCart("+al.size()+")");
		        
		        
				
				
				
				
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
		switch (v.getId()) {
		case R.id.btnback:
			finish();
			
			break;
		case R.id.btnhomesignout:
			//set loggedin value as false
			prefs=getSharedPreferences("myprefs",MODE_APPEND);
			Editor edit=prefs.edit();
			edit.putBoolean("buyerlogedin", false);
			edit.putString("email", "");
			edit.commit();
			
			
			Intent logout=new Intent(MycartActivity.this, MainActivity.class);
			startActivity(logout);
			finishAffinity();
		
			break;
		case R.id.btnbuy:
			boolean flag=false;
			String checkproduct=purchaseproduct.getText().toString().trim();
			for(String s:check){
				
				if(checkproduct.equals(s)){
					
					flag=true;
					break;
					
					
					
				}
				}
				
				if(flag){
					
					prefs=getSharedPreferences("myprefs", MODE_APPEND);
					String email=prefs.getString("email", "");
					Cart db=new Cart(MycartActivity.this);
					db.open();
					int id=db.delete(email, checkproduct);
					
					db.close();
					if(id==-1){
						Toast.makeText(MycartActivity.this, "Error in deleting", Toast.LENGTH_SHORT).show();
					}
					else{
						
						ProductDB pdb=new ProductDB(MycartActivity.this);
						pdb.open();
						int up=pdb.selectAndUpdateProductDB(checkproduct);
						pdb.close();
						if(up==0){
						Toast.makeText(MycartActivity.this, "Not updated in ProductDB", Toast.LENGTH_SHORT).show();
						}else
						{
							Toast.makeText(MycartActivity.this, "Successfully Purchased.", Toast.LENGTH_LONG).show();
						}
					}
					Intent i=new Intent(MycartActivity.this, MycartActivity.class);
					startActivity(i);
					finish();
					
					
					   ProductdetailActivity.fa.finish();
					
				}
				else{
					Toast.makeText(MycartActivity.this, "Enter Valid Product", Toast.LENGTH_SHORT).show();
				}
				
			
			
			
			break;
		default:
			break;
		}
		
		
	}

}
