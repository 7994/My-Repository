package com.example.buyersellerdemo;



import DataBase.Cart;
import DataBase.ProductDB;
import Pojo.Product;
import android.app.Activity;

import android.content.Intent;

import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;

import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class ProductdetailActivity extends Activity implements OnClickListener{
	
	private TextView name;
	private TextView quantity;
	private TextView price;
	private Button btnlogout;
	private Button btnback;
	private Button btnadd;
	private Button btnmycart;
	private SharedPreferences prefs;
	
	//Object of Product pojo
	Product p;
	
	
	public static Activity fa;
	
	   
	
	
	
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		getActionBar().hide();
		setContentView(R.layout.activity_productdetail);
		
		
		 fa = this;
		
		
		//TextView ids
		name=(TextView)findViewById(R.id.txtname);
		quantity=(TextView)findViewById(R.id.txtquantity);
		price=(TextView)findViewById(R.id.txtprice);
		
		
		
		
		
		
		//button ids
		btnlogout=(Button)findViewById(R.id.btnhomesignout);
		btnlogout.setText("Logout");
		btnback=(Button)findViewById(R.id.btnback);
		btnadd=(Button)findViewById(R.id.btnaddtocart);
		btnmycart=(Button)findViewById(R.id.btnmycart);
		btnlogout.setOnClickListener(this);
		btnback.setOnClickListener(this);
		btnadd.setOnClickListener(this);
		btnmycart.setOnClickListener(this);
		
		Intent i = getIntent();
		
		Bundle extra = i.getExtras();
		
		String value = extra.getString("ProductName").trim();
		
		
		ProductDB db=new ProductDB(ProductdetailActivity.this);
		db.open();
		
		p = db.getproductdetail(value);
		db.close();
		
		String pname=p.getPname();
		String pquantity=p.getPquantity();
		String pprice=p.getPprice();
		
		name.setText(pname);
		quantity.setText(pquantity);
		price.setText(pprice);
		
	}
//	
//@Override
//protected void onPause() {
//	// TODO Auto-generated method stub
//	super.onPause();
//	Intent a=new Intent(ProductdetailActivity.this, BuyerhomeActivity.class);
//	startActivity(a);
//	finish();
//}
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.btnback:
//			Intent a=new Intent(ProductdetailActivity.this, BuyerhomeActivity.class);
//			startActivity(a);
			finish();
			
			//onPause();
			
			break;
		case R.id.btnhomesignout:
			//set loggedin value as false
			prefs=getSharedPreferences("myprefs",MODE_APPEND);
			Editor edit=prefs.edit();
			edit.putBoolean("buyerlogedin", false);
			edit.putString("email", "");
			edit.commit();
			
			
			Intent logout=new Intent(ProductdetailActivity.this, MainActivity.class);
			startActivity(logout);
			finishAffinity();
			break;
		case R.id.btnaddtocart:
			
			prefs=getSharedPreferences("myprefs", MODE_APPEND);
			String email=prefs.getString("email", "");
			Cart db=new Cart(ProductdetailActivity.this);
			db.open();
			long id=db.insertintoCart(email,p.getPname() ,p.getPquantity(),p.getPprice());
			
			db.close();
			if(id==-1){
				Toast.makeText(ProductdetailActivity.this, "You can't add more than one same product.", Toast.LENGTH_SHORT).show();
			}
			else{
				Toast.makeText(ProductdetailActivity.this, "Product added to your Cart.", Toast.LENGTH_SHORT).show();
				
				
			}
			
			break;
		case R.id.btnmycart:
			
			
			
			Intent i=new Intent(ProductdetailActivity.this, MycartActivity.class);
			
			startActivity(i);
			
			
			
			
	
	break;

		default:
			break;
		}
	}
	 
	

}
