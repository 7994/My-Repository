package com.example.buyersellerdemo;


import DataBase.ProductDB;
import Pojo.Product;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SellerhomeActivity extends Activity implements OnClickListener{
	
	

	private Button btnlogout;
	private Button btnback;
	private SharedPreferences prefs;
	private Button btnadd;
	private EditText productname;
	private EditText productquantity;
	private EditText productprice;
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		getActionBar().hide();
		setContentView(R.layout.activity_sellerhome);
		btnlogout=(Button)findViewById(R.id.btnhomesignout);
		btnlogout.setText("Logout");
		btnback=(Button)findViewById(R.id.btnback);
		
		btnlogout.setOnClickListener(this);
		btnback.setOnClickListener(this);
		
		btnadd=(Button)findViewById(R.id.btnadd);
		btnadd.setOnClickListener(this);
		
		//edittext ids
		productname=(EditText)findViewById(R.id.editproductname);
		productquantity=(EditText)findViewById(R.id.editquantity);
		productprice=(EditText)findViewById(R.id.editprice);
		
		
		
		
		
		
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
		switch (v.getId()) {
		case R.id.btnback:
			finish();
			
			break;
		
		case R.id.btnhomesignout:
			//set loggedin value as false
			prefs=getSharedPreferences("myprefs",MODE_APPEND);
			Editor edit=prefs.edit();
			edit.putBoolean("sellerlogedin", false);
			
			edit.commit();
			
			Intent logout=new Intent(SellerhomeActivity.this, MainActivity.class);
			startActivity(logout);
			finishAffinity();
			break;
		case R.id.btnadd:
			boolean name=false,quantity=false,price=false;
			String pname,pquantity,pprice;
			pname=productname.getText().toString().trim();
			pquantity=productquantity.getText().toString().trim();
			pprice=productprice.getText().toString().trim();
			
			Product p=new Product();
			p.setPname(pname);
			p.setPquantity(pquantity);
			p.setPprice(pprice);
			
			
			if(!pname.matches("^.{2,}$"))
			{
				productname.setError("Name must be min 3 char long.");
			}
			else{
				name=true;
			}
			if(!pquantity.matches("^[0-9]{1,}$")){
				productquantity.setError("Minimum quantity 1.");
			}
			else{
				quantity=true;
			}
			if(!pprice.matches("^[0-9]{1,}$")){
				productprice.setError("Minimum price 0 Rs.");
			}
			else{
				price=true;
			}
			
			
			
			if(name&&quantity&&price){
				
				
			
			
			ProductDB db=new ProductDB(SellerhomeActivity.this);
			db.open();
			
			long id=db.insertProduct(p);
		
			db.close();
			
			if(id==-1){
				Toast.makeText(SellerhomeActivity.this, "This Product is already added.", Toast.LENGTH_SHORT).show();
				productquantity.setText("");
				productprice.setText("");
			}
			else{
				Toast.makeText(SellerhomeActivity.this, "Product Added succeccfully.", Toast.LENGTH_SHORT).show();
				productname.setText("");
				productquantity.setText("");
				productprice.setText("");
			}
				
				
			}
			
			break;

		default:
			break;
		}
		
		
	}
	}


