package com.example.buyersellerdemo;

import DataBase.LoginDB;
import DataBase.SellerDB;
import DataBase.SellerDataBase;
import Pojo.Seller;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class SellersignupActivity extends Activity implements OnClickListener{
	private Button btngotologin;
	private Button btnback;
	private Button btnsubmit;
	private EditText editshopname;
	private EditText editemail;
	private EditText editphonenumber;
	private EditText editpassword;
	private SharedPreferences prefs;
	private TextView title;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		getActionBar().hide();
		setContentView(R.layout.activity_sellersignup);
		
		//EditText Ids
		editshopname=(EditText)findViewById(R.id.editshopname);
		editemail=(EditText)findViewById(R.id.editemail);
		editphonenumber=(EditText)findViewById(R.id.editphonenumber);
		editpassword=(EditText)findViewById(R.id.editpassword);
		//Button ids
		btngotologin=(Button)findViewById(R.id.btnhomesignout);
		btngotologin.setText("Login");
		btnback=(Button)findViewById(R.id.btnback);
		btnsubmit=(Button)findViewById(R.id.btnsubmit);
		
		//TextView id
				title=(TextView)findViewById(R.id.txttitle);
		//Initialize Shared Preference
				prefs=getSharedPreferences("myprefs", MODE_APPEND);
				String text=prefs.getString("loger", null);
				
				//Set Title
				title.setText(text);
		
		//Button Click
		btngotologin.setOnClickListener(this);
		btnback.setOnClickListener(this);
		btnsubmit.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.btnback:
			
			
			finish();
			
			break;
		case R.id.btnhomesignout:
			
			Intent j=new Intent(SellersignupActivity.this, MainActivity.class);
			startActivity(j);
			finishAffinity();
			
			break;
		case R.id.btnsubmit:
			
			submit();
			break;

		default:
			break;
		}
		
	}
	
	
	//Button submit method 
	private void submit(){
		prefs=getSharedPreferences("myprefs", MODE_APPEND);
		String loger=prefs.getString("loger", null);
		
		String name,email,phonenumber,password;
		boolean flagname=false,flagemail=false,flagphonenumber=false,flagpassword=false;
		
		name=editshopname.getText().toString().trim();
		email=editemail.getText().toString().trim();
		phonenumber=editphonenumber.getText().toString().trim();
		password=editpassword.getText().toString().trim();
		
		Seller seller=new Seller();
		seller.setShopname(name);
		seller.setEmail(email);
		seller.setPhonenumber(phonenumber);
		seller.setPassword(password);			
		seller.setLoger(loger);
		//Validation check for Shopname
		if(!name.matches("^[a-zA-Z//s]{3,}$"))
		{
			editshopname.setError("Enter aphabet only.");
			
		}		
		else
		{			
			flagname=true;
		}
		
		//Validation check for Email
		if(!email.matches("^[A-Za-z][A-Za-z0-9]*([._-]?[A-Za-z0-9]+)@[A-Za-z].[A-Za-z]{0,13}?.[A-Za-z]{0,3}$"))
		{
			editemail.setError("Enter valid Email id.");
			
		}
		else
		{			
			flagemail=true;
		}
		
		//Validation check for Phonenumber
		if(!phonenumber.matches("^[0-9]*$")){
			editphonenumber.setError("Enter valid number");
		}
		else
		{
			flagphonenumber=true;
		}
		
		//Validation check for Password
		if(!password.matches("^.{4,10}$")){
			editpassword.setError("Enter Valid password");
		}
		else
		{
			flagpassword=true;
		}
		if(flagname&&flagemail&&flagphonenumber&&flagpassword){
			
//			Toast.makeText(SellersignupActivity.this, "All Valid", Toast.LENGTH_SHORT).show();
			
			
			//Create object of class SellerDB
			      SellerDB dbseller=new SellerDB(SellersignupActivity.this);
			//Open dbseller
			      dbseller.open();
			
			//insert shopename,emai,phonenumber into SellerDB
			
			long id=dbseller.insertintoSellerDB(seller);
			
			//close dbseller
			dbseller.close();
			
			if(id==-1){
				Toast.makeText(SellersignupActivity.this, "Enter Unique Shopname", Toast.LENGTH_SHORT).show();
				
			}
			else
			{
				//Create object of class LoginDB
				LoginDB dblogin=new LoginDB(SellersignupActivity.this);
				//Open dbLogin
				dblogin.open();
				
				//insrt email,password,loger into LoginDB
				long id1=dblogin.insertintoLoginDB(seller);
				//Close dblogin
				dblogin.close();
				
				if(id1==-1){
					Toast.makeText(SellersignupActivity.this, "Error while inserting.", Toast.LENGTH_SHORT).show();
				}
				else
				{
					Toast.makeText(SellersignupActivity.this, "Signup Successfull. ", Toast.LENGTH_LONG).show();
					Intent i=new Intent(SellersignupActivity.this, SellerhomeActivity.class);
					startActivity(i);
					finish();
				}
				
			}

			
			
			
		}
		
	}

}
