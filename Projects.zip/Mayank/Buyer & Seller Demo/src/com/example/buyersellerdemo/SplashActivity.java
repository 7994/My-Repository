package com.example.buyersellerdemo;

import android.os.Bundle;
import android.os.Handler;
import android.widget.ImageView;
import android.app.Activity;
import android.content.Intent;


public class SplashActivity extends Activity {

    private ImageView ivGif;

	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        
        
        
       
        
        
        
        //Hide actionbar
        //requestWindowFeature(Window.FEATURE_NO_TITLE);
        getActionBar().hide();
        //Create Runnable interface reference
        Runnable r=new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				
				//Create Intent to go to next screen
				Intent i=new Intent(SplashActivity.this, MainActivity.class);
				startActivity(i);
				finish();
				
				
			}
		};
		
		//create Handler class object to handle splash
        Handler h=new Handler();
        h.postDelayed(r, 1800);
    }


   
}
