package com.database.db;

import java.util.ArrayList;

import com.database.pojo.Person;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;


public class PersonDB  {
	
	// Database table details
	private static final String KEY_ROW_ID = "_id";
	private static final String KEY_PERSON_NAME = "name";
	private static final String KEY_ADDRESS = "address";
	private static final String KEY_EMAIL = "email";
	private static final String KEY_PHONENUMBER = "phonenumber";
	private static final String DATABASE_TABLE = "person";
	private static final String DATABASE_NAME = "personData";
	
	private static final int DATABASE_VERSION = 1;
	
	private static final String[] columns = {KEY_ROW_ID, KEY_PERSON_NAME, KEY_ADDRESS, KEY_EMAIL, KEY_PHONENUMBER};
	
	
	// Useful objects
	private final Context ourContext;
	private DBHelper ourHelper;
	private SQLiteDatabase ourDatabase;

	
	// DBHelper Class Start -----------------------------------------------------------
	private class DBHelper extends SQLiteOpenHelper {

		public DBHelper(Context context) {
			
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
			// TODO Auto-generated constructor stub
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			// TODO Auto-generated method stub
			
			String query = "CREATE TABLE IF NOT EXISTS " +DATABASE_TABLE + 
					" (" +KEY_ROW_ID+" INTEGER PRIMARY KEY AUTOINCREMENT, " 
					+ KEY_PERSON_NAME +" TEXT NOT NULL, " 
					+ KEY_ADDRESS +" TEXT NOT NULL, "
					+ KEY_EMAIL +" TEXT NOT NULL, " 
					+ KEY_PHONENUMBER +" TEXT NOT NULL);" ;
			
			Log.d("SQL Query", query);
			
			db.execSQL(query);
			
			
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			// TODO Auto-generated method stub
			
			db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE);
			onCreate(db);
			
		}
		
	}
	// DBHelper Class Finish -----------------------------------------------------------	
	
	// PersonDB class functions 
	
	
	// Constructor
	
	public PersonDB(Context context){
		this.ourContext = context;
	}
	
	
	// Database operations 
	
	
	// Open
	public PersonDB open () {
		
		ourHelper = new DBHelper(ourContext);
		
		ourDatabase = ourHelper.getWritableDatabase();
		
		return this;

	}
	
	// Close
	
	public void close() {
		ourHelper.close();
	}
	
	
	//create -- insert one row
	
	public long insert (String name, String address, String email, String phonenumber) {
		
		ContentValues values = new ContentValues();
		
		values.put(KEY_PERSON_NAME, name);
		values.put(KEY_ADDRESS, address);
		values.put(KEY_EMAIL, email);
		values.put(KEY_PHONENUMBER, phonenumber);
		
		return ourDatabase.insert(DATABASE_TABLE, null, values);
	
	}
	
	
	public long insertObject (Person p) {

		ContentValues values = new ContentValues();
		
		values.put(KEY_PERSON_NAME, p.getName());
		values.put(KEY_ADDRESS, p.getAddress());
		values.put(KEY_EMAIL, p.getEmail());
		values.put(KEY_PHONENUMBER, p.getPhoneNumber());
		
		return ourDatabase.insert(DATABASE_TABLE, null, values);
		
	}
	
	// create -- insert multiple row
	
	public void insertMultipleObjects(ArrayList<Person> people){
		
		for(Person p : people) {
			
			ContentValues values = new ContentValues();
			
			values.put(KEY_PERSON_NAME, p.getName());
			values.put(KEY_ADDRESS, p.getAddress());
			values.put(KEY_EMAIL, p.getEmail());
			values.put(KEY_PHONENUMBER, p.getPhoneNumber());
			
			ourDatabase.insert(DATABASE_TABLE, null, values);
		}
	}
	
	// read one row
	public Person getOnePerson(long id) {
		
		Person data = new Person();
		
		Cursor c = ourDatabase.query(DATABASE_TABLE, columns,KEY_ROW_ID +"=" + id, null, null, null, null);
		
		if(c.moveToFirst()) {
			
		int iName =	c.getColumnIndex(KEY_PERSON_NAME);
		int iAddress = c.getColumnIndex(KEY_ADDRESS);
		int iEmail = c.getColumnIndex(KEY_EMAIL);
		int iPhonenumber = c.getColumnIndex(KEY_PHONENUMBER);
			
		String name = c.getString(iName);
		String address = c.getString(iAddress);
		String email = c.getString(iEmail);
		String phoneNumber = c.getString(iPhonenumber);
		
		data.setName(name);
		data.setAddress(address);
		data.setEmail(email);
		data.setPhoneNumber(phoneNumber);
			
		}
		
		return data;
		
	}
	
	
	// read multiple row
	
	public ArrayList<Person> getAllPeople() {
		
		ArrayList<Person> people = new ArrayList<Person>();
		
		Cursor c = ourDatabase.query(DATABASE_TABLE, columns,null, null, null, null, null);
		
		
		for(c.moveToFirst(); !c.isAfterLast(); c.moveToNext()) {
		
		Person data = new Person();
		int iName =	c.getColumnIndex(KEY_PERSON_NAME);
		int iAddress = c.getColumnIndex(KEY_ADDRESS);
		int iEmail = c.getColumnIndex(KEY_EMAIL);
		int iPhonenumber = c.getColumnIndex(KEY_PHONENUMBER);
		
			
		String name = c.getString(iName);
		String address = c.getString(iAddress);
		String email = c.getString(iEmail);
		String phoneNumber = c.getString(iPhonenumber);
		
		data.setName(name);
		data.setAddress(address);
		data.setEmail(email);
		data.setPhoneNumber(phoneNumber);
		
		people.add(data);
		
		}
		
		
		return people;
	}
	
	
	//update
	
	public void updateName(long id, String name){
		
		ContentValues values = new ContentValues();
		
		values.put(KEY_PERSON_NAME, name);
		
		ourDatabase.update(DATABASE_TABLE, values, KEY_ROW_ID +"=" + id, null);
		
	}
	
	// delete one entry
	
	public int deleteById(long id) {
		
		return ourDatabase.delete(DATABASE_TABLE, KEY_ROW_ID +"=" + id, null);
		
	}
	
	// delete all
	
	public void deleteAll() {
		
		ourDatabase.delete(DATABASE_TABLE, null, null);
	}
	
}
