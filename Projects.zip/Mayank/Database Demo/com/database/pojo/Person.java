package com.database.pojo;

import java.util.List;

public class Person {
	
	private String name;
	private String address;
	private String email;
	private String phoneNumber;
	
	private List<Address> localAddresses;
	
	private Address homeAddress;
	
	private Address officeAdddress;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
	
	public Address getHomeAddress() {
		return homeAddress;
	}
	public void setHomeAddress(Address homeAddress) {
		this.homeAddress = homeAddress;
	}
	
	public Address getOfficeAdddress() {
		return officeAdddress;
	}
	public void setOfficeAdddress(Address officeAdddress) {
		this.officeAdddress = officeAdddress;
	}
	
	public List<Address> getLocalAddresses() {
		return localAddresses;
	}
	public void setLocalAddresses(List<Address> localAddresses) {
		this.localAddresses = localAddresses;
	}
	
	
	

}
