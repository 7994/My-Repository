package com.databasedemo;

import java.util.ArrayList;

import com.database.db.PersonDB;
import com.database.pojo.Address;
import com.database.pojo.Person;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

	private EditText editName;
	private EditText editAddress;
	private EditText editEmail;
	private EditText editNumber;
	private Button btnSave;
	
	private Person person;
	private Button btnRead;
	private TextView textData;
	private long id;
	private Button btnMulti;
	private Button btnMultiRead;
	private Button btnUpdate;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		editName = (EditText) findViewById(R.id.editText1);
		editAddress = (EditText) findViewById(R.id.editText2);
		editEmail = (EditText) findViewById(R.id.editText3);
		editNumber = (EditText) findViewById(R.id.editText4);
		
		textData = (TextView) findViewById(R.id.textView2);
		
		btnSave = (Button) findViewById(R.id.btnSave);
		
		
		
		
		person = new Person();
		
		btnSave.setOnClickListener(new OnClickListener() {
			
	

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				String name = editName.getText().toString();
				String address = editAddress.getText().toString();
				String email = editEmail.getText().toString();
				String number = editNumber.getText().toString();
				
				person.setName(name);
				person.setAddress(address);
				person.setEmail(email);
				person.setPhoneNumber(number);
				
				
				Address home = new Address();
				home.setStreetName("xyz street");
				home.setCity("baroda");
				home.setState("Guj");
				home.setCountry("IND");
				home.setZipcode("123456");
				
				
				person.setHomeAddress(home);
				
				
				
				/// Database insert 
				PersonDB db = new PersonDB(MainActivity.this);
				//open database
				db.open();
				
//				db.insert(name, address, email, number);
				
				id = db.insertObject(person);
				
				//close database
				db.close();
				
				
			}
		});
		
		btnRead = (Button) findViewById(R.id.btnRead);
		
		btnRead.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				
				//Read from database
				
				PersonDB read = new PersonDB(MainActivity.this);
				
				read.open();
				
				Person p = read.getOnePerson(id);
				
				read.close();
				
				String name = p.getName();
				String address = p.getAddress();
				String email = p.getEmail();
				String number = p.getPhoneNumber();
				
				
				String data = "Welcome " + name +" "+ address +" "+ email +" "+ number;
				
				textData.setText(data);
				
				
			}
		});
		
		// Insert multiple row
		btnMulti = (Button) findViewById(R.id.btnMulti);
		btnMulti.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				ArrayList<Person> list = new ArrayList<Person>();
				
				for (int i = 0; i < 5; i++) {
					
					Person person = new Person();
					
					person.setName("Name " + i);
					person.setAddress("Address " + i);
					person.setEmail("Email " + i);
					person.setPhoneNumber("Number " + i);
					
					list.add(person);
				}
				
				PersonDB db = new PersonDB(MainActivity.this);
				db.open();
				db.insertMultipleObjects(list);
				db.close();
				
				
			}
		});
		
		
		// REad all DAta
		
		btnMultiRead = (Button) findViewById(R.id.btnMultiRead);
		btnMultiRead.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				ArrayList<Person> list = new ArrayList<Person>();
				
				PersonDB db = new PersonDB(MainActivity.this);
				db.open();
				
				list = db.getAllPeople();
				
				db.close();
				
				for(Person p : list) {
					Toast.makeText(MainActivity.this, p.getName(), Toast.LENGTH_SHORT).show();
				}
				
				
			}
		});
		
		
		// update
		
		btnUpdate = (Button) findViewById(R.id.btnUpdate);
		
		btnUpdate.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				PersonDB db = new PersonDB(MainActivity.this);
				db.open();
				//db.updateName(1, "James");
				
				int result = db.deleteById(3);
				if(result == 0) {
					Toast.makeText(MainActivity.this, "Failed", Toast.LENGTH_SHORT).show();
				}else{
					Toast.makeText(MainActivity.this, "Success", Toast.LENGTH_SHORT).show();
				}
				db.close();
			}
		});
		
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
