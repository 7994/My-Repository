package com.example.externaldemo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import android.os.Bundle;
import android.os.Environment;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity implements OnClickListener {

    private EditText externaldata;
	private Button save;
	private Button read;
	private TextView resultdata;

	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    
        //EditText id
    externaldata=(EditText)findViewById(R.id.editexternaldata);
    
       //Button ids
    
    save=(Button)findViewById(R.id.btnsave);
    read=(Button)findViewById(R.id.btnread);
    
      //Result id
    resultdata=(TextView)findViewById(R.id.txtexternaldata);
    
    
    save.setOnClickListener(this);
    read.setOnClickListener(this);
    
    
    
    
    }

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
		switch (v.getId()) {
		case R.id.btnsave:
			String data1=externaldata.getText().toString();
			save(data1);
			externaldata.setText("");
			
			break;
		case R.id.btnread:
			String result=read();
			resultdata.setText(result);
			break;

		default:
			break;
		}
		
	}
	//Creating FIle in external Storage
	
	
	
	//Saveing data into external storage
	public void save(String data) {
		
		String path=Environment.getExternalStorageDirectory().getPath();
		File myfile=new File(path+"/montu.txt");
		
		try {
			myfile.createNewFile();
			FileOutputStream out=new FileOutputStream(myfile);
			out.write(data.getBytes());
			out.close();
			Toast.makeText(getApplicationContext(), "File saved to external storage", Toast.LENGTH_LONG).show();
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			Toast.makeText(getApplicationContext(), "Error in writing data", Toast.LENGTH_LONG).show();

		}
		
		
		
		
		
		
	}
	
	public String read() {
		String temp="";
		String path=Environment.getExternalStorageDirectory().getPath();
		File myfile=new File(path+"/montu.txt");
		try {
			FileInputStream in=new FileInputStream(myfile);
			int c;
			
			while((c=in.read())!=-1){
				char ch=(char)c;
				temp=temp+Character.toString(ch);
				
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			Toast.makeText(getApplicationContext(), "File not found", Toast.LENGTH_LONG).show();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			Toast.makeText(getApplicationContext(), "Error in reading data", Toast.LENGTH_LONG).show();
		}
		
		
		
		return temp;
		
	}
	
	
    }


   
    
