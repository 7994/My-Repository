package com.example.internaldemo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity implements OnClickListener {

   
	private EditText data;
	private Button save;
	private Button read;
	private TextView result;


	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        //EditText id        
        data=(EditText)findViewById(R.id.editinternaldata);
        
        //Button ids
        save=(Button)findViewById(R.id.btnsave);
        read=(Button)findViewById(R.id.btnread);
        
        //Result id
        result=(TextView)findViewById(R.id.txtresult);
        
        //Button click events
        save.setOnClickListener(this);
        read.setOnClickListener(this);
        
        
        //geting path of app
        String p=getFilesDir().getAbsolutePath();
        data.setText(p);
        
        
    }


	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
		switch (v.getId()) {
		case R.id.btnsave:
			String d=data.getText().toString();
			save(d);
			data.setText("");
			Toast.makeText(getApplicationContext(), "Data saved to internal", Toast.LENGTH_LONG).show();
			
			break;
		case R.id.btnread:
			result.setText(read());
			
			break;

		default:
			break;
		}
		
	}
	
	//Saveing data into Internal Storage
	public void save(String data){
		
		FileOutputStream out;
		try {
			out = openFileOutput("montu.txt",MODE_PRIVATE);
			out.write(data.getBytes());
			out.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			Toast.makeText(getApplicationContext(),"File not found",Toast.LENGTH_LONG).show();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			Toast.makeText(getApplicationContext(),"Error in writing",Toast.LENGTH_LONG).show();
		}
		
		
		
	}

	//Reading data from Internal Storage
	public String read(){
		String resultdata="";
		try {
			FileInputStream in=openFileInput("montu.txt");
			int c;
			while ((c=in.read())!=-1) {
				char ch=(char)c;
				resultdata=resultdata+Character.toString(ch);
				
			}
			in.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			Toast.makeText(getApplicationContext(), "FIle not found", Toast.LENGTH_LONG).show();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			Toast.makeText(getApplicationContext(), "Error in reading", Toast.LENGTH_LONG).show();
		}
		return resultdata;

}
}