package com.example.login.register;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends Activity {
	
	//creating Object of View Component
	private EditText txtlogin,txtpass;
	private Button btnLogin;
	private CheckBox checkbox;
	private boolean flagtext=false,flagpass=false;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_login);
      
        //initializing view components
        txtlogin=(EditText)findViewById(R.id.txtlogin);
        txtpass=(EditText)findViewById(R.id.txtpass);
        btnLogin=(Button)findViewById(R.id.btnLogin);
        checkbox=(CheckBox)findViewById(R.id.checkBox1);
        
        
        //On click event start
        btnLogin.setOnClickListener(new OnClickListener() {
			
        	
			       	
			@Override
			public void onClick(View v) {

				String text;
				String pass;
				text=txtlogin.getText().toString().trim();
				pass=txtpass.getText().toString().trim();
				

				
				// TODO Auto-generated method stub
				if(text.equals("admin"))
				{
					flagtext=true;
				}
				if(pass.equals("admin"))
				{
					flagpass=true;
				}
				
				if(flagtext&&flagpass){
				Intent second=new Intent(LoginActivity.this, RegistrationActivity.class);
				startActivity(second);
				
	//Remember me code start			
				if(checkbox.isChecked())
				{
				
				}
				else
					{
					txtlogin.setText("");
					txtpass.setText("");
					}
	//Remember me code end				
					
				//finish();
				}
				
				if(!flagtext&&flagpass){
					txtlogin.setError("Invalid Id");
					Toast.makeText(LoginActivity.this, "Invalid Login Id",Toast.LENGTH_SHORT).show();
				}
				
				if(flagtext&&!flagpass){
					txtpass.setError("Invalid Password");
					Toast.makeText(LoginActivity.this, "Invalid Password",Toast.LENGTH_SHORT).show();
				}
				if(!flagtext&&!flagpass){
					txtlogin.setError("Invalid Id");
					txtpass.setError("Invalid Password");
					
					Toast.makeText(LoginActivity.this, "Invalid Login Id and Password",Toast.LENGTH_SHORT).show();
				}
				
				flagpass=false;
				flagtext=false;
				
				
			}
		});
        
    
        
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.login, menu);
        return true;
    }
    
}
