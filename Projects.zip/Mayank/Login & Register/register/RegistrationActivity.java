package com.example.login.register;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;

public class RegistrationActivity extends Activity {
	
	//Declaration of view components
	private EditText txtName;
	private EditText txtEmail;
	private EditText txtPhone;
	private EditText txtAge;
	private Button btnSubmit;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_registration);
		
		//Initializing view components
		txtName=(EditText)findViewById(R.id.txtName);
		txtEmail=(EditText)findViewById(R.id.txtEmail);
		txtPhone=(EditText)findViewById(R.id.txtPhone);
		txtAge=(EditText)findViewById(R.id.txtAge);
		btnSubmit=(Button)findViewById(R.id.btnSubmit);
		
		
		
		
				
		//Submit button click event starts
		btnSubmit.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				Intent i=new Intent(RegistrationActivity.this,ShowRegistrationActivity.class);
				
				txtName.setError("name require");
				
				//taking values of components into String variables
				String name,email,phone,age;
				
				name=txtName.getText().toString().trim();
				email=txtEmail.getText().toString().trim();
				phone=txtPhone.getText().toString().trim();
				age=txtAge.getText().toString().trim();
				boolean flagname=false,flagemail=false;
				//Validation check for Name
				if(!name.matches("^[a-zA-Z\\s]*$"))
				{
					txtName.setError("Enter aphabet only.");
					
				}
				else
				{
					
					flagname=true;
				}
				
				
				
				//Validation check for Email
				if(!email.matches("^[A-Za-z][A-Za-z0-9]*([._-]?[A-Za-z0-9]+)@[A-Za-z].[A-Za-z]{0,13}?.[A-Za-z]{0,3}$"))
				{
					txtEmail.setError("Enter valid Email id.");
					
				}
				else
				{
					
					flagemail=true;
				}
				
				
				
				if(flagname&&flagemail)
				{
					i.putExtra("Name", name);
					i.putExtra("Email",email);
					i.putExtra("Phone", phone);
					i.putExtra("Age", age);
				    
					startActivity(i);
					finish();
					}
				flagemail=false;
				flagname=false;
			
			    }
			
		});
		
	}

}
