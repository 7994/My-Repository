package com.example.login.register;

import java.security.PublicKey;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;

public class ShowRegistrationActivity extends Activity{
	
	

	private TextView txtcongrats;
	private TextView txtemail;
	private TextView txtphone;
	private TextView txtage;
	String n,e,p,a;
	private Button btnback;


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_show);
		
		txtcongrats=(TextView)findViewById(R.id.txtcongrats);
		txtemail=(TextView)findViewById(R.id.txtemaildynamic);
		txtphone=(TextView)findViewById(R.id.txtphonedynamic);
		txtage=(TextView)findViewById(R.id.txtagedynamic);
		btnback=(Button)findViewById(R.id.btnBack);
		
		
		Intent intent=getIntent();		
		Bundle bundle=intent.getExtras();
		
	    
		
		n=bundle.getString("Name");
		e=bundle.getString("Email");
		p=bundle.getString("Phone");
		a=bundle.getString("Age");
		
		txtcongrats.setText("Congratulation "+n.toUpperCase()+".");
		txtemail.setText(e);
		txtphone.setText(p);
		txtage.setText(a);
		
		
		
	}
	public void Back(View v) {
		Intent back=new Intent(ShowRegistrationActivity.this,RegistrationActivity.class);
		startActivity(back);
		finish();
		
	}

}
