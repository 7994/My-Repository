package ApiCall;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONException;
import org.json.JSONObject;

import com.example.phpdet.MainActivity;

import android.widget.Toast;

public class HttpCall {
	
	public static String addproduct(String url,ArrayList<NameValuePair> nameValuePairs){
		
		String result =null;
		
		
		try {
			HttpClient client =new DefaultHttpClient();
			HttpPost request =new HttpPost(url);
			UrlEncodedFormEntity entity;
			entity = new UrlEncodedFormEntity(nameValuePairs);
			request.setEntity(entity);
			
			HttpResponse response =client.execute(request);
			
			InputStream content =response.getEntity().getContent();
			result =conveStreamToString(content);
			
			
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClientProtocolException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
			
		return result;
		
		
		
		
		
	}
	
	
	private static String conveStreamToString(InputStream content)	{
		
		String result =null;
		BufferedReader reader;
		try {
			reader =new BufferedReader(new InputStreamReader(content,"UTF-8"));
			StringBuilder builder =new StringBuilder();
			String line=null;
			while((line=reader.readLine())!=null){
				
				builder.append(line);
				
				
				
			}
			content.close();
			
			String temp = builder.toString();
			JSONObject obj = new JSONObject(temp);
			
			String c =obj.getString("code");
			if(c.equals("1")){
				result ="Success";
			}else
			{
				result ="Fail";
			}
			
			
			
			
			
			
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	
		return result;
		
		
	}

}
