package com.example.phpdet;

import ApiCall.ApiCall;
import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.app.ProgressDialog;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {

	private EditText editName;
	private EditText editQty;
	private EditText editPrice;
	private Button btnAdd;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		editName =(EditText)findViewById(R.id.editText1);
		editQty =(EditText)findViewById(R.id.editText2);
		editPrice =(EditText)findViewById(R.id.editText3);
		
		
		btnAdd =(Button)findViewById(R.id.button1);
		
		btnAdd.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				
				
				new AddAsyncProduct().execute();
				
				
				
				
			}
		});
		
		
		
		
	}
	
	
	
	

	private class AddAsyncProduct extends AsyncTask<Void, Void, String>
	{
		ProgressDialog dialog;
		
		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			dialog = new ProgressDialog(MainActivity.this);
			dialog.setMessage("Inserted..");
			dialog.setCancelable(true);
			dialog.show();
			
			
		}

		@Override
		protected String doInBackground(Void... params) {
			// TODO Auto-generated method stub
			
			
			
			String result =null;
			String name =editName.getText().toString().trim();
			String qty =editQty.getText().toString().trim();
			String price =editPrice.getText().toString().trim();
			
			ApiCall api =new ApiCall();
			
			//result=api.addproduct(name, qty, price);
			result =api.addproduct(name, qty, price);
			
			
			return result;
		}
		
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			if(result.equals("")){
				Toast.makeText(MainActivity.this ,"Data Inserted", Toast.LENGTH_LONG).show();
				dialog.dismiss();
			}
			if(result.equals("success")){
				Toast.makeText(MainActivity.this ,"Data Inserted", Toast.LENGTH_LONG).show();
				dialog.dismiss();
				
			}
			if(result.equals("error"))
			{
				Toast.makeText(MainActivity.this,"Error..", Toast.LENGTH_LONG).show();
			}
			dialog.dismiss();
		}
		
	}
	

}
