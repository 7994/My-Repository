<?php

//Getting Data
$name = $_POST['pname'];
$qty = $_POST['pqty'];
$price = $_POST['pprice'];
//$name="abc";
//$qty="5";
//$price="25";


//open connection
$conn=mysqli_connect("localhost","root","","productdemo");
if(!$conn)
{
trigger_error('could not connect '.mysqli_connect_error());
}
//Insert query
$sql="INSERT INTO productdetail(Name,Qty,Price) VALUES('$name','$qty','$price')";

//$array=array();




//Query fire
if($conn->query($sql)===TRUE
){
//$array['moon']="1";
$flag['code']="1";
//echo "Data added successfully";
}
else{
//$array[]="0";
$flag['code']="0";
//echo "Error in adding data---".$conn->error;
}
print(json_encode($flag));
//Connection close
$conn->close();




?>