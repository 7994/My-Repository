<?php

//Getting Data
$id=$_POST['pid'];

//$id="1111";


//open connection
$conn=mysqli_connect("mysql.hostinger.in","u841647886_moon","moonmoon","u841647886_prod");
if(!$conn)
{
trigger_error('could not connect '.mysqli_connect_error());
}
//delete query

$sql="DELETE FROM productdetail WHERE Id='$id'";
//Query fire
 $objQuery = $conn->query($sql);

   $r=mysqli_affected_rows($conn);

if($r>0)
{
 $flag['code']="1";
}
else
{
 $flag['code']="0";
}


print(json_encode($flag));

//Connection close
$conn->close();
?>			