<?php
$conn=mysqli_connect("localhost","root","","moon_db");
$select=mysqli_query($conn,"SELECT * FROM product_tb");
$array="";
while($raw=mysqli_fetch_assoc($select))
{
$array["data"][]=$raw;
}
echo json_encode($array);
die;
?>