<?php
//open connection to database
$conn=mysqli_connect("localhost","root","","productdemo");
//$conn=mysqli_connect("mysql.hostinger.in","u841647886_moon","moonmoon","u841647886_prod");
if(!$conn)
{
trigger_error('could not connect '.mysqli_connect_error());
}
//fatch table raws from database
$sql="SELECT * FROM productdetail";
$result=mysqli_query($conn,$sql);

//create array
$array=array();
while($raw=mysqli_fetch_assoc($result))
{
$array["products"][]=$raw;
}
echo json_encode($array);
//echo '{"Data":'.json_encode($array).'}';
//print(json_encode($array));
mysqli_close($conn);

?>