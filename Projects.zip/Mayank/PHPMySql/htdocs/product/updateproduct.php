<?php

//Getting Data
$id=$_POST['pid'];
$name = $_POST['pname'];
$qty = $_POST['pqty'];
$price = $_POST['pprice'];
//$id=11
//$name="abc";
//$qty="5";
//$price="25";

//open connection
$conn=mysqli_connect("mysql.hostinger.in","u841647886_moon","moonmoon","u841647886_prod");
if(!$conn)
{
trigger_error('could not connect '.mysqli_connect_error());
}
//Update query
$sql="UPDATE productdetail SET Name=".$name." ,Qty=".$qty." ,Price=".$price." WHERE Id=".$id."";

//Query fire
if($conn->query($sql)===TRUE)
{
 $flag['code']="1";
}
else
{
 $flag['code']="0";
}

print(json_encode($flag));

//Connection close
$conn->close();
?>