package ApiCall;

import java.util.ArrayList;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

public class APICall {
	
	public String addproduct(String name,String qty,String price){
		String result=null;
		//creating URL
		String url=APIResources.BASE_URL+APIResources.ADD_PRODUCT;
		
		//Creat Arraylist to store name,qty and price in namevaluepair
		ArrayList<NameValuePair> nameValuePairs=new ArrayList<NameValuePair>();
		nameValuePairs.add(new BasicNameValuePair("pname", name));
		nameValuePairs.add(new BasicNameValuePair("pqty", qty));
		nameValuePairs.add(new BasicNameValuePair("pprice", price));
		
		//call HTTPCall class
		result=HTTPCall.addproduct(url, nameValuePairs);
		
		
		return result;
	}
	
	//update
	public String updateproduct(String id,String name,String qty,String price){
		String result=null;
		//creating URL
		String url=APIResources.BASE_URL+APIResources.UPDATE_PRODUCT;
		
		//Creat Arraylist to store name,qty and price in namevaluepair
		ArrayList<NameValuePair> nameValuePairs=new ArrayList<NameValuePair>();
		nameValuePairs.add(new BasicNameValuePair("pid", id));
		nameValuePairs.add(new BasicNameValuePair("pname", name));
		nameValuePairs.add(new BasicNameValuePair("pqty", qty));
		nameValuePairs.add(new BasicNameValuePair("pprice", price));
		
		//call HTTPCall class
		result=HTTPCall.addproduct(url, nameValuePairs);
		
		
		return result;
	}
	//delete 
	public String deleteproduct(String id){
		String result=null;
		String url=APIResources.BASE_URL+APIResources.DELETE_PRODUCT;
		
		ArrayList<NameValuePair> nameValuePairs=new ArrayList<NameValuePair>();
		nameValuePairs.add(new BasicNameValuePair("pid", id));
		result=HTTPCall.addproduct(url, nameValuePairs);
		return result;
	}
	
	public String getallproducts(){
		
		String result=null;
		
		String url=APIResources.BASE_URL+APIResources.GET_PRODUCT;
		result=HTTPCall.getallproduct(url);
		
		
		return result;
	}
	public String getdetailproduct(String id){
		String result=null;
		String url=APIResources.BASE_URL+APIResources.GET_DETAIL_PRODUCT;
		
		ArrayList<NameValuePair> nameValuePairs=new ArrayList<NameValuePair>();
		nameValuePairs.add(new BasicNameValuePair("Id", id));
		result=HTTPCall.getdetailproduct(url,nameValuePairs);
		return result;
	}
	

}
