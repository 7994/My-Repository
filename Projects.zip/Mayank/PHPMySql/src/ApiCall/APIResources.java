package ApiCall;

public class APIResources {
	
	public static final String BASE_URL="http://www.mayank.890m.com/";
	//public static final String BASE_URL="http://192.168.1.4/product/";
	public static final String ADD_PRODUCT="addproduct.php";
	public static final String GET_PRODUCT="getproduct.php";
	public static final String GET_DETAIL_PRODUCT="getdetailproduct.php";
	public static final String UPDATE_PRODUCT="updateproduct.php";
	public static final String DELETE_PRODUCT="deleteproduct.php";
	

}
