package com.example.phpmysql;


import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;



import ApiCall.APICall;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;

public class GetProductActivity extends Activity{
	private ListView list;
	private ArrayList<String> productdata;
//	private ListAdapter adapter;
//	private ArrayList<HashMap<String, String>> personList;
    private ArrayAdapter<String> adapter;
	private String myJson;
	private JSONArray productdata1;
	private ImageButton btnimg;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_allproduct);
		
		list=(ListView)findViewById(R.id.listView1);
		 productdata=new ArrayList<String>();
		adapter=new ArrayAdapter<String>(GetProductActivity.this, android.R.layout.simple_list_item_1, productdata);
		// adapter=new SimpleAdapter(GetProductActivity.this, personList, R.layout.list_item, new String[]{"Id","Name"}, new int[]{R.id.txtId,R.id.txtName});
		 list.setAdapter(adapter);
		
		boolean status=AddproductActivity.haveNetworkConnection(GetProductActivity.this);
		if(status){
			 //call asynck class to get list of product
			new getproduct().execute();
		}
		if(!status){
			Toast.makeText(GetProductActivity.this, "No Network availabe", Toast.LENGTH_SHORT).show();
		}
		 
		
		
		btnimg=(ImageButton)findViewById(R.id.imageButton1);
		btnimg.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent i=getIntent();
				startActivity(i);
				finish();
			}
		});
		
		//listitem click
		list.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				 //call asynck class to get list of product
				boolean status=AddproductActivity.haveNetworkConnection(GetProductActivity.this);
				if(status){
				String id=productdata.get(arg2);
				String subId=id.substring(0, id.indexOf(" ")).trim();
		
				Intent i=new Intent(GetProductActivity.this,ItemListActivity.class);
				i.putExtra("id", subId);
				startActivity(i);
				}
				if(!status){
					Toast.makeText(GetProductActivity.this, "No internet connecction", Toast.LENGTH_SHORT).show();
				}
			}
		});
		
		
	}
	
	//Asynck task class
	private class getproduct extends AsyncTask<Void, Void, String>{
		private ProgressDialog dialog;
		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			dialog = new ProgressDialog(GetProductActivity.this);
			dialog.setMessage("Loading Products...!");
			dialog.show();
			super.onPreExecute();
		}
		@Override
		protected String doInBackground(Void... params) {
			// TODO Auto-generated method stub
			//ProductData alldata = new ProductData();
			String result=null;
			APICall api = new APICall();
			result = api.getallproducts();
			
			return result;
			
		}
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			if(result!=null){
				myJson=result;
				showList();
			}
			else{
				Toast.makeText(GetProductActivity.this, "Result is null", Toast.LENGTH_SHORT).show();
			}
					
			dialog.dismiss();
			
		}
		
	}
	private void showList(){
		
		try {
			JSONObject jsonObject=new JSONObject(myJson);
			productdata1=jsonObject.getJSONArray("products");
			
			for(int i=0;i<productdata1.length();i++){
				JSONObject c=productdata1.getJSONObject(i);
				String id=c.getString("Id");
				String name=c.getString("Name");
			    productdata.add(id+"  "+name);
//				 HashMap<String,String> persons = new HashMap<String,String>();
//				 persons.put("Id", id);
//				 persons.put("Name", name);
//				 personList.add(persons);
			}
			 adapter.notifyDataSetChanged();
			
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
