package com.example.phpmysql;


import org.json.JSONException;
import org.json.JSONObject;

import ApiCall.APICall;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class ItemListActivity extends Activity{
	
	private String id;
	private String myJson;
	private TextView id1;
	private EditText name1;
	private EditText qty1;
	private EditText price1;
	private Button btnupdate;
	private Button btndelete;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.list_item);
		
		Intent data = getIntent();
		Bundle extra = data.getExtras();
		id=extra.getString("id");
		new getDetail().execute();
		
		
		
		//Update Button
		btnupdate=(Button)findViewById(R.id.btnUpdate);
		btndelete=(Button)findViewById(R.id.btnDelete);
		
		btndelete.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				new DeleteData().execute();						
			}
		});
		btnupdate.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				new UpdateData().execute();						
			}
		});
		
	}
	
	//Update data async class
	private class UpdateData extends AsyncTask<Void, Void, String>{
		private ProgressDialog dialog;
		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			dialog = new ProgressDialog(ItemListActivity.this);
			dialog.setMessage("Updating Products...!");
			dialog.show();
			super.onPreExecute();
		}
		@Override
		protected String doInBackground(Void... params) {
			// TODO Auto-generated method stub
			String result=null;
			
			String id,name,qty,price;
			id=id1.getText().toString().trim();
			name=name1.getText().toString().trim();
			qty=qty1.getText().toString().trim();
			price=price1.getText().toString().trim();
			APICall api=new APICall();
			result=api.updateproduct(id,name, qty, price);
			
			return result;
		}
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			if(result.equals("success")){
				Toast.makeText(ItemListActivity.this, "Data Updated", Toast.LENGTH_SHORT).show();
			}
			if(result.equals("error")){
				Toast.makeText(ItemListActivity.this, "You must update atleast One field value.", Toast.LENGTH_SHORT).show();
			}
			dialog.dismiss();
		}
		
	}
	
	//Delete product async class
	private class DeleteData extends AsyncTask<Void, Void, String>{
		private ProgressDialog dialog;
		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			dialog = new ProgressDialog(ItemListActivity.this);
			dialog.setMessage("Deleting Products...!");
			dialog.show();
			super.onPreExecute();
		}
		@Override
		protected String doInBackground(Void... params) {
			// TODO Auto-generated method stub
			String result=null;
			
			String id;
			id=id1.getText().toString().trim();
			
			APICall api=new APICall();
			result=api.deleteproduct(id);
			
			return result;
		}
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			if(result.equals("success")){
				Toast.makeText(ItemListActivity.this, "Data Deleted", Toast.LENGTH_SHORT).show();
				id1.setText("");
				name1.setText("");
				qty1.setText("");
				price1.setText("");
			}
			if(result.equals("error")){
				Toast.makeText(ItemListActivity.this, "Data not Deleted", Toast.LENGTH_SHORT).show();
			}
			
			dialog.dismiss();
		}
		
	}
	
	
	
	//getdetail data async class
	private class getDetail extends AsyncTask<Void, Void, String>{
		private ProgressDialog dialog;
		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			dialog = new ProgressDialog(ItemListActivity.this);
			dialog.setMessage("Loading Products...!");
			dialog.show();
			super.onPreExecute();
		}
		@Override
		protected String doInBackground(Void... params) {
			// TODO Auto-generated method stub
			String result=null;
			APICall api = new APICall();
			result = api.getdetailproduct(id);
			return result;
		}
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			if(result!=null){
				myJson=result;
				showList();
			}
			else{
				Toast.makeText(ItemListActivity.this, "Result is null", Toast.LENGTH_SHORT).show();
			}
					
			dialog.dismiss();
		}
		
	}
	public void showList(){
		
		try {
			
			JSONObject object=new JSONObject(myJson);
			JSONObject a=object.getJSONObject("products");
			//JSONArray array=object.getJSONArray("products");
			String id = null,name = null,qty = null,price = null;
			
			
			//JSONObject o=array.getJSONObject(array.length());
			id=a.getString("Id");
			name=a.getString("Name");
			qty=a.getString("Qty");
			price=a.getString("Price");
			
			
			id1=(TextView)findViewById(R.id.txtId);
			name1=(EditText)findViewById(R.id.editName);
			qty1=(EditText)findViewById(R.id.editQty);
			price1=(EditText)findViewById(R.id.editPrice);
			
			id1.setText(id);
			name1.setText(name);
			qty1.setText(qty);
			price1.setText(price);
			
			
			
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			Toast.makeText(ItemListActivity.this, "JSON Exception", Toast.LENGTH_SHORT).show();
			e.printStackTrace();
		}
		
		
	}
	
	//Update button 
	
	
	

}
