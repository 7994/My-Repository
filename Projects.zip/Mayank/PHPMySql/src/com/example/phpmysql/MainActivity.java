package com.example.phpmysql;

import com.example.phpmysql.R;


import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;

import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity {

    private Button btnAdd;
	private Button btnShow;

	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        //Button Ids
        btnAdd=(Button)findViewById(R.id.btnAdd);
        btnShow=(Button)findViewById(R.id.btnShow);
        
        //btnAdd click action
        btnAdd.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent i=new Intent(MainActivity.this,AddproductActivity.class);
				startActivity(i);
			}
		});
        
        //btnShow click action
        btnShow.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				boolean status=AddproductActivity.haveNetworkConnection(MainActivity.this);
				if(status){
					 //call asynck class to get list of product
					Intent j=new Intent(MainActivity.this,GetProductActivity.class);
					startActivity(j);
				}
				if(!status){
					Toast.makeText(MainActivity.this, "No Network availabe", Toast.LENGTH_SHORT).show();
				}
				
			}
				
			
		});
        
    }

    
}
