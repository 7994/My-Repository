package data;

import java.util.List;

import table.Product;

public class ProductData {

private List<Product> products;

public List<Product> getProducts() {
	return products;
}

public void setProducts(List<Product> products) {
	this.products = products;
}

	
}
