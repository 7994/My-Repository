package Dataabase;

import java.util.ArrayList;

import pojo.Product;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class ProductDB {
	
	private static final String KEY_RAW_ID="Id";
	private static final String KEY_PNAME="Pname";
	private static final String KEY_PQTY="Pqty";
	private static final String KEY_PPRICE="Pprice";
	
	private static final String DATABASE_NAME="ProductDB";
	private static final String DATABASE_TABLE="Productdata";
	
	private static final int DATABASE_VERSION=1;
	
	private static final String[] column={KEY_PNAME};
	
	//Useful objects
	private final Context outContext;
	private DBHelper ourHelper;
	private SQLiteDatabase ourDatabase;
	
	public ProductDB(Context context){
		this.outContext=context;
	}
	
	private class DBHelper extends SQLiteOpenHelper{

		public DBHelper(Context context) {
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
			// TODO Auto-generated constructor stub
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			// TODO Auto-generated method stub
			String query = "CREATE TABLE IF NOT EXISTS " +DATABASE_TABLE + 
					" (" +KEY_RAW_ID+" INTEGER PRIMARY KEY AUTOINCREMENT, " 
					+ KEY_PNAME +" TEXT NOT NULL, " 
					+ KEY_PQTY +" TEXT NOT NULL, "
					+ KEY_PPRICE +" TEXT NOT NULL);" ;
			
			Log.d("SQL Query", query);
			
			db.execSQL(query);
			
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			// TODO Auto-generated method stub
			db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE);
			onCreate(db);
		}
		
	}
	
	public ProductDB open(){
		
		ourHelper=new DBHelper(outContext);
		ourDatabase=ourHelper.getWritableDatabase();
		
		return this;
	}
	public void close(){
		ourHelper.close();
	}
	
	
	//insert 
	public long insert(String name,String qty,String price){
		ContentValues values=new ContentValues();
		values.put(KEY_PNAME, name);
		values.put(KEY_PQTY, qty);
		values.put(KEY_PPRICE, price);
		
	return 	ourDatabase.insert(DATABASE_TABLE, null, values);
		
		
		
		
	}

	//read all
	public ArrayList<Product> getAllProduct(){
		ArrayList<Product> products=new ArrayList<Product>();
		
		Cursor c=ourDatabase.query(DATABASE_TABLE, column, null, null, null, null, null);
		
		for(c.moveToFirst();!c.isAfterLast();c.moveToNext()){
			
			Product data=new Product();
			
			int iPname=c.getColumnIndex(KEY_PNAME);
			int iPqty=c.getColumnIndex(KEY_PQTY);
			int iPprice=c.getColumnIndex(KEY_PPRICE);
			
			
			
		}
		
		
		return products;
	}
}
