package pojo;

public class Product {
	
	private String Pname;
	private String Pqty;
	private String Pprice;
	public String getPname() {
		return Pname;
	}
	public void setPname(String pname) {
		Pname = pname;
	}
	public String getPqty() {
		return Pqty;
	}
	public void setPqty(String pqty) {
		Pqty = pqty;
	}
	public String getPprice() {
		return Pprice;
	}
	public void setPprice(String pprice) {
		Pprice = pprice;
	}
	

}
