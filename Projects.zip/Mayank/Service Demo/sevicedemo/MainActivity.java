package com.example.sevicedemo;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity extends Activity implements OnClickListener{

    private Button start;
	private Button stop;

	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        start=(Button)findViewById(R.id.btnStart);
        stop=(Button)findViewById(R.id.btnStop);
        start.setOnClickListener(this);
        stop.setOnClickListener(this);
    }

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.btnStart:
			Intent start=new Intent(this, Service.class);
			startService(start);
			break;

		case R.id.btnStop:
			Intent stop=new Intent(this, Service.class);
			stopService(stop);
			break;
		}
	}


    
}
