package com.example.sharedprefs;


import android.os.Bundle;
import android.os.Environment;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {

    private SharedPreferences prefs;
	private EditText uname;
	private EditText pass;
	private CheckBox check;
	private Button login;
	private String un;
	private String up;
	private boolean flaguname=false,flagpass=false;


	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       
        
        
        prefs=getSharedPreferences("mayank",MODE_PRIVATE);
        boolean status=prefs.getBoolean("status", false);
        
        if(status){
        	Intent i=new Intent(MainActivity.this,second_activity.class);
        	startActivity(i);
        	finish();
        	
        }
        
        
               
        uname=(EditText)findViewById(R.id.edituname);
        pass=(EditText)findViewById(R.id.editpass);
        check=(CheckBox)findViewById(R.id.checkremember);
        login=(Button)findViewById(R.id.btnlogin);
        
       
//        String p=Environment.getDataDirectory().getPath();
//        
//        uname.setText(p);
        
        
        login.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				 
				 
				 
				   un=uname.getText().toString().trim();
			       up=pass.getText().toString().trim();
				 
			       if(check.isChecked()){
			        	Editor edit=prefs.edit();
			        	edit.putBoolean("status", true);
			        	edit.commit();
			        }
				if(un.equals("admin")){
					flaguname=true;
					
				}
				if(up.equals("admin")){
					flagpass=true;
					
				}
				if(flaguname&&flagpass){
					Toast.makeText(getApplicationContext(), "login clicked",Toast.LENGTH_SHORT).show();
					Intent home=new Intent(getApplicationContext(),second_activity.class);
					startActivity(home);
					finish();
					
				}
				flagpass=false;
				flaguname=false;
				
				
			}
		});
        
        
      
        
        
    }


   
    
}
