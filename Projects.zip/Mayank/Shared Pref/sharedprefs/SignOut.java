package com.example.sharedprefs;

public class SignOut {

}
