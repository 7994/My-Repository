package com.example.sharedprefs;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class second_activity extends Activity {

	
	private Button save;
	private Button read;
	private Button back;
	private Button sout;
	private SharedPreferences prefs;
	private SharedPreferences prefss;
	
	
	
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_second);
		
		
		
		save=(Button)findViewById(R.id.btnsave);
		read=(Button)findViewById(R.id.btnread);
		back=(Button)findViewById(R.id.btnback);
		sout=(Button)findViewById(R.id.btnsout);
		
		prefss=getSharedPreferences("mayank1",MODE_PRIVATE);
		
		save.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				String name=((EditText)findViewById(R.id.editname)).getText().toString().trim();
				String age=((EditText)findViewById(R.id.editage)).getText().toString().trim();
				
				Editor edit=prefss.edit();
				edit.putString("name", name);				
				edit.putString("age", age);
				edit.commit();
				
				((EditText)findViewById(R.id.editname)).setText("");
				((EditText)findViewById(R.id.editage)).setText("");
				
				Toast.makeText(getApplicationContext(), "Data Saved", Toast.LENGTH_LONG).show();
				
				
			}
		});
		
		read.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent read=new Intent(second_activity.this,third_activity.class);
				startActivity(read);
				finish();
				
			
				Toast.makeText(getApplicationContext(), "Read clicked", Toast.LENGTH_LONG).show();
				
			}
		});
		back.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent back=new Intent(second_activity.this,MainActivity.class);
				startActivity(back);
				finish();
				
			}
		});
		
		sout.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				prefs=getSharedPreferences("mayank",MODE_PRIVATE);
				Editor edit=prefs.edit();
				edit.putBoolean("status", false);
				edit.commit();
				Intent back=new Intent(second_activity.this,MainActivity.class);
				startActivity(back);
				finish();
							}
		});
		
		
	}
	
	

}
