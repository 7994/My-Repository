package com.example.sharedprefs;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class third_activity  extends Activity{
	
	private SharedPreferences prefss;
	private Button back;
	private Button out;
	private TextView user;
	private TextView age;
	second_activity a=new second_activity();
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_third);
		
		
		
		prefss=getSharedPreferences("mayank1",MODE_PRIVATE);
		user=(TextView)findViewById(R.id.txtuser);
		String n=prefss.getString("name", null);
		user.setText(n);
		
		age=(TextView)findViewById(R.id.txtage);
		String a=prefss.getString("age",null);
		age.setText(a);
		
		
		back=(Button)findViewById(R.id.btnback);
		
		back.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Editor edit=prefss.edit();
				edit.putString("name","");				
				edit.putString("age","");
				edit.commit();
				Intent back=new Intent(third_activity.this,second_activity.class);
				startActivity(back);
				finish();
				
				
			}
		});
		
		
		out=(Button)findViewById(R.id.btnsout);
		out.setOnClickListener(new OnClickListener() {
			
			private SharedPreferences prefs;

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				prefs=getSharedPreferences("mayank",MODE_PRIVATE);
				Editor edit=prefs.edit();
				edit.putBoolean("status", false);
				edit.commit();
				Intent back=new Intent(third_activity.this,MainActivity.class);
				startActivity(back);
				finish();
				
			}
		});
		
	}

}
