package ApiCall;

import java.util.ArrayList;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import android.util.Log;

public class ApiCall {
	
	public String addproduct(String name,String qty,String price)
	{
		String result =null;
		String url = ApiResource.BASE_URL + ApiResource.ADD_PRODUCT;
		Log.d(name, "Name");
		ArrayList<NameValuePair> nameValuePairs =new ArrayList<NameValuePair>();
		
		nameValuePairs.add(new BasicNameValuePair("pname", name));
		nameValuePairs.add(new BasicNameValuePair("pqty", qty));
		nameValuePairs.add(new BasicNameValuePair("pprice", price));
		
		result = HttpCall.addproduct(url, nameValuePairs);
		
		
		
		
		return result;
		
	}

}
