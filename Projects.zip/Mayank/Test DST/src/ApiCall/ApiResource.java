package ApiCall;

public class ApiResource {
	
	
	public static final String BASE_URL ="http://192.168.43.253:81/product/";
	public static final String ADD_PRODUCT ="product.php";
	
	

}
