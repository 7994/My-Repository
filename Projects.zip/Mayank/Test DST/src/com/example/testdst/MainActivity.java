package com.example.testdst;



import ApiCall.ApiCall;
import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.app.ProgressDialog;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {

	private EditText editname;
	private EditText editqty;
	private EditText editprice;
	private Button btnadd;

	String result;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		editname =(EditText)findViewById(R.id.editText1);
		editqty =(EditText)findViewById(R.id.editText2);
		editprice =(EditText)findViewById(R.id.editText3);
		
		btnadd =(Button)findViewById(R.id.button1);
		
		btnadd.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				//new AddAsyncProduct().execute();
				
				new abc().execute();
				
			}
		});
		
	}
	
	
	
	public class abc extends AsyncTask<Void, Void, String>{

		ProgressDialog dialog;
		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			// TODO Auto-generated method stub
			dialog = new ProgressDialog(MainActivity.this);
			dialog.setMessage("Inserted..");
			dialog.setCancelable(true);
			dialog.show();
			
			
			
			
		
		}
		@Override
		protected String doInBackground(Void... params) {
			// TODO Auto-generated method stub
			
			String result =null;
			String name =editname.getText().toString().trim();
			String qty =editqty.getText().toString().trim();
			String price =editprice.getText().toString().trim();
			
			ApiCall api =new ApiCall();
			
			result =api.addproduct(name, qty, price);
			
			
			return result;
		}
		
		
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			
			if(result.equals("")){
				Toast.makeText(MainActivity.this ,"Data Inserted", Toast.LENGTH_LONG).show();
				dialog.dismiss();
			}
			if(result.equals("success")){
				Toast.makeText(MainActivity.this ,"Data Inserted", Toast.LENGTH_LONG).show();
				dialog.dismiss();
				
			}
			if(result.equals("error"))
			{
				Toast.makeText(MainActivity.this,"Error..", Toast.LENGTH_LONG).show();
			}
			dialog.dismiss();
		}
			
			
			
		}
		
	}
	
	
	
	
 

 
	 
 

	

