package com.example.whatsapp;

import java.io.File;


import java.util.ArrayList;




import android.os.Bundle;
import android.os.Environment;

import android.app.Activity;
import android.graphics.Bitmap;

import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import android.widget.ListView;

import android.widget.Toast;

public class MainActivity extends Activity implements OnClickListener{

    private ListView list;
	private ArrayAdapter<String> aa;
	private ArrayList<String> al;
	private ArrayList<String> a2;
	private Button btnphoto;
	private Button btnpics;
	 public String path;
	 public File dir;
	private TextView text;
	 

	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        text=(TextView)findViewById(R.id.textView1);
        
      //ListView id
        list=(ListView)findViewById(R.id.listView1 );
        
        //Button ids
        btnphoto=(Button)findViewById(R.id.btnphoto);
        btnpics=(Button)findViewById(R.id.btnpicture);
        
        //Creating ArrayList Object
        
      
        
       
        
       
               
        btnphoto.setOnClickListener(this);
        btnpics.setOnClickListener(this);
       
        
        
       


   
    
	}


	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.btnphoto:
			
		    text.setText("");
		    al=new ArrayList<String>();
			
			 path=Environment.getExternalStorageDirectory().getAbsolutePath();
			dir = new File(path+"/WhatsApp/Media/WhatsApp Profile Photos");
			String  photo[]=dir.list();
		        if (photo == null) {
			         Toast.makeText(getApplicationContext(), "Empty", Toast.LENGTH_SHORT).show();
			         text.setText("Empty Folder");
//			         al.add("Empty Folder");
			      }
				  else {
			         for (int i=0; i< photo.length; i++) {
			            String filename = photo[i];
			            al.add(filename);
			            }      
		        
		       
		       
		        
		    }
		      //Creating ArrayAdapter Object
		        aa=new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1, al);
		        //Setiing Adapter in list
		        list.setAdapter(aa);   

			
			break;
		case R.id.btnpicture:
		    text.setText("");
		    a2=new ArrayList<String>();
			 path=Environment.getExternalStorageDirectory().getAbsolutePath();
			dir = new File(path+"/WhatsApp/Profile Pictures");
			String photoo[]=dir.list();
		        if (photoo == null) {
			         Toast.makeText(getApplicationContext(), "Empty", Toast.LENGTH_SHORT).show();
			         text.setText("Empty Folder");
//			         a2.add("Empty Folder");
			      }
				  else {
			         for (int i=0; i< photoo.length; i++) {
			            String filename = photoo[i];
			            a2.add(filename);
			            }      
		        
		       
		        
		    }
		      //Creating ArrayAdapter Object
		        aa=new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1, a2);
		        //Setiing Adapter in list
		        list.setAdapter(aa);   

		
		    break;

		default:
			break;
		}
		
		
		
		
	}

        
        
}


